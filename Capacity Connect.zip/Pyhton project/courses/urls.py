from django.urls import path

from . import views

app_name = "courses"

urlpatterns = [
    path("", views.catalog, name="catalog"),
    path("my-learning/", views.my_learning, name="my_learning"),
    path("certificates/", views.my_certificates, name="certificates"),
    path("certificates/verify/", views.verify_certificate, name="verify"),
    path("certificates/<str:code>/", views.certificate, name="certificate"),
    path("competencies/", views.competencies, name="competencies"),
    # Trainer studio
    path("studio/", views.studio, name="studio"),
    path("studio/new/", views.course_create, name="create"),
    path("studio/<slug:slug>/", views.course_manage, name="manage"),
    path("studio/<slug:slug>/edit/", views.course_edit, name="edit"),
    path("studio/<slug:slug>/delete/", views.course_delete, name="delete"),
    path("studio/<slug:slug>/learners/", views.course_learners, name="learners"),
    path("studio/<slug:slug>/modules/add/", views.module_add, name="module_add"),
    path("modules/<oid:pk>/edit/", views.module_edit, name="module_edit"),
    path("modules/<oid:pk>/delete/", views.module_delete, name="module_delete"),
    path("modules/<oid:module_pk>/lessons/add/", views.lesson_form, name="lesson_add"),
    path("lessons/<oid:pk>/edit/", views.lesson_form, name="lesson_edit"),
    path("lessons/<oid:pk>/delete/", views.lesson_delete, name="lesson_delete"),
    path("lessons/<oid:lesson_id>/complete/", views.complete_lesson, name="complete_lesson"),
    # Learner course pages
    path("<slug:slug>/", views.course_detail, name="detail"),
    path("<slug:slug>/enroll/", views.enroll, name="enroll"),
    path("<slug:slug>/review/", views.review, name="review"),
    path("<slug:slug>/learn/", views.learn, name="learn"),
    path("<slug:slug>/learn/<oid:lesson_id>/", views.learn, name="learn_lesson"),
]
