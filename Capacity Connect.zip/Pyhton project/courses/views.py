from collections import defaultdict

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.decorators import can_manage_course, trainer_required
from assessments.models import Attempt, Quiz

from .forms import CourseForm, LessonForm, ModuleForm, ReviewForm
from .models import Category, Certificate, Competency, Course, Enrollment, Lesson, LessonProgress, Module, Review
from .services import attach_course_stats, check_course_completion, passed_quiz_ids, progress_map


def _managed_course(request, slug):
    course = get_object_or_404(Course, slug=slug)
    if not can_manage_course(request.user, course):
        raise PermissionDenied
    return course


# ---------------------------------------------------------------- learners

@login_required
def catalog(request):
    courses = Course.objects.filter(status=Course.Status.PUBLISHED).select_related("category", "instructor")
    q = request.GET.get("q", "").strip()
    category = request.GET.get("category", "")
    level = request.GET.get("level", "")
    sort = request.GET.get("sort", "newest")
    if q:
        courses = courses.filter(Q(title__icontains=q) | Q(summary__icontains=q) | Q(description__icontains=q))
    if category:
        courses = courses.filter(category__slug=category)
    if level:
        courses = courses.filter(level=level)
    if request.GET.get("mandatory"):
        courses = courses.filter(is_mandatory=True)
    courses = attach_course_stats(courses, request.user)
    if sort == "popular":
        courses.sort(key=lambda c: c.num_enrolled, reverse=True)
    elif sort == "rating":
        courses.sort(key=lambda c: c.rating, reverse=True)
    elif sort == "title":
        courses.sort(key=lambda c: c.title.lower())
    return render(request, "courses/catalog.html", {
        "courses": courses,
        "categories": Category.objects.all(),
        "levels": Course.Level.choices,
        "q": q, "category": category, "level": level, "sort": sort,
        "mandatory": request.GET.get("mandatory", ""),
    })


@login_required
def course_detail(request, slug):
    course = get_object_or_404(Course.objects.select_related("category", "instructor"), slug=slug)
    manager = can_manage_course(request.user, course)
    if not course.is_published and not manager:
        raise Http404
    attach_course_stats([course], request.user)
    modules = list(course.modules.prefetch_related("lessons"))
    done = set(
        LessonProgress.objects.filter(user=request.user, lesson__module__course=course).values_list("lesson_id", flat=True)
    )
    for m in modules:
        m.lesson_list = list(m.lessons.all())
        for lesson in m.lesson_list:
            lesson.done = lesson.pk in done
    quizzes = list(course.quizzes.all())
    passed = passed_quiz_ids(request.user, [q.pk for q in quizzes])
    for quiz in quizzes:
        quiz.passed = quiz.pk in passed
        quiz.num_questions = quiz.questions.count()
    my_review = Review.objects.filter(course=course, user=request.user).first()
    certificate = Certificate.objects.filter(course=course, user=request.user).first()
    total_minutes = sum(lesson.duration_minutes for m in modules for lesson in m.lesson_list)
    return render(request, "courses/detail.html", {
        "course": course,
        "modules": modules,
        "quizzes": quizzes,
        "reviews": course.reviews.select_related("user")[:10],
        "review_form": ReviewForm(instance=my_review),
        "my_review": my_review,
        "certificate": certificate,
        "is_manager": manager,
        "total_minutes": total_minutes,
        "competencies": course.competencies.all(),
    })


@login_required
@require_POST
def enroll(request, slug):
    course = get_object_or_404(Course, slug=slug, status=Course.Status.PUBLISHED)
    _, created = Enrollment.objects.get_or_create(user=request.user, course=course)
    if created:
        messages.success(request, f"You're enrolled in “{course.title}”. Let's begin!")
    return redirect("courses:learn", slug=slug)


@login_required
def learn(request, slug, lesson_id=None):
    course = get_object_or_404(Course, slug=slug)
    enrollment = Enrollment.objects.filter(user=request.user, course=course).first()
    if not enrollment and not can_manage_course(request.user, course):
        messages.info(request, "Enroll in this course to start learning.")
        return redirect(course)
    modules = list(course.modules.prefetch_related("lessons"))
    lessons = [lesson for m in modules for lesson in m.lessons.all()]
    if not lessons:
        messages.info(request, "This course has no lessons yet.")
        return redirect(course)
    done = set(
        LessonProgress.objects.filter(user=request.user, lesson_id__in=[l.pk for l in lessons]).values_list("lesson_id", flat=True)
    )
    if lesson_id:
        lesson = next((l for l in lessons if str(l.pk) == lesson_id), None)
        if lesson is None:
            raise Http404
    else:
        resume = enrollment.last_lesson if enrollment else None
        lesson = next((l for l in lessons if l.pk not in done), None) or (resume or lessons[0])
    idx = next(i for i, l in enumerate(lessons) if l.pk == lesson.pk)
    for m in modules:
        m.lesson_list = list(m.lessons.all())
        for l in m.lesson_list:
            l.done = l.pk in done
    if enrollment and enrollment.last_lesson_id != lesson.pk:
        enrollment.last_lesson = lesson
        enrollment.save(update_fields=["last_lesson"])
    quizzes = list(course.quizzes.all())
    passed = passed_quiz_ids(request.user, [q.pk for q in quizzes])
    for quiz in quizzes:
        quiz.passed = quiz.pk in passed
    return render(request, "courses/learn.html", {
        "course": course,
        "modules": modules,
        "lesson": lesson,
        "is_done": lesson.pk in done,
        "prev_lesson": lessons[idx - 1] if idx > 0 else None,
        "next_lesson": lessons[idx + 1] if idx + 1 < len(lessons) else None,
        "progress": progress_map(request.user, [course.pk])[course.pk],
        "position": idx + 1,
        "total": len(lessons),
        "quizzes": quizzes,
        "enrollment": enrollment,
    })


@login_required
@require_POST
def complete_lesson(request, lesson_id):
    lesson = get_object_or_404(Lesson.objects.select_related("module__course"), pk=lesson_id)
    course = lesson.module.course
    if not Enrollment.objects.filter(user=request.user, course=course).exists():
        raise PermissionDenied
    LessonProgress.objects.get_or_create(user=request.user, lesson=lesson)
    certificate = check_course_completion(request.user, course)
    if certificate:
        messages.success(request, f"🎉 Congratulations! You completed “{course.title}” and earned a certificate.")
        return redirect(certificate)
    next_id = request.POST.get("next")
    if next_id:
        return redirect("courses:learn_lesson", slug=course.slug, lesson_id=next_id)
    lesson_ids = set(course.lessons().values_list("id", flat=True))
    done_ids = set(LessonProgress.objects.filter(user=request.user, lesson_id__in=list(lesson_ids)).values_list("lesson_id", flat=True))
    if lesson_ids - done_ids:
        return redirect("courses:learn", slug=course.slug)
    passed = passed_quiz_ids(request.user)
    remaining = [q for q in course.quizzes.all() if q.pk not in passed]
    if remaining:
        messages.info(request, "All lessons done! Pass the assessment to complete the course.")
        return redirect(remaining[0])
    return redirect("courses:learn_lesson", slug=course.slug, lesson_id=lesson.pk)


@login_required
@require_POST
def review(request, slug):
    course = get_object_or_404(Course, slug=slug)
    if not Enrollment.objects.filter(user=request.user, course=course).exists():
        raise PermissionDenied
    instance = Review.objects.filter(course=course, user=request.user).first()
    form = ReviewForm(request.POST, instance=instance)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.course, obj.user = course, request.user
        obj.save()
        messages.success(request, "Thanks for your feedback!")
    return redirect(course.get_absolute_url() + "#reviews")


@login_required
def my_learning(request):
    enrollments = list(Enrollment.objects.filter(user=request.user).select_related("course", "course__category", "last_lesson"))
    courses = attach_course_stats([e.course for e in enrollments], request.user)
    return render(request, "courses/my_learning.html", {
        "in_progress": [c for c in courses if not c.my_enrollment.is_completed],
        "completed": [c for c in courses if c.my_enrollment.is_completed],
    })


@login_required
def my_certificates(request):
    return render(request, "courses/certificates.html", {
        "certificates": Certificate.objects.filter(user=request.user).select_related("course", "course__category"),
    })


def certificate(request, code):
    """Public, printable certificate page — doubles as a verification link."""
    cert = get_object_or_404(Certificate.objects.select_related("user", "course", "course__instructor"), code=code.upper())
    return render(request, "courses/certificate.html", {"cert": cert})


def verify_certificate(request):
    code = request.GET.get("code", "").strip().upper()
    cert = Certificate.objects.filter(code=code).select_related("user", "course").first() if code else None
    return render(request, "courses/verify.html", {"code": code, "cert": cert, "searched": bool(code)})


@login_required
def competencies(request):
    """Competency framework with the user's proficiency in each competency."""
    comps = list(Competency.objects.all())
    links = defaultdict(set)
    published = set(Course.objects.filter(status=Course.Status.PUBLISHED).values_list("id", flat=True))
    through = Course.competencies.through.objects.filter(course_id__in=list(published))
    for course_id, comp_id in through.values_list("course_id", "competency_id"):
        links[comp_id].add(course_id)
    completed = set(
        Enrollment.objects.filter(user=request.user, completed_at__isnull=False).values_list("course_id", flat=True)
    )
    progress = progress_map(request.user, list(published))
    courses_by_id = {c.pk: c for c in Course.objects.filter(id__in=list(published))}
    areas = defaultdict(list)
    for comp in comps:
        ids = links[comp.pk]
        comp.course_list = [courses_by_id[i] for i in ids]
        comp.score = round(sum(progress.get(i, 0) for i in ids) / len(ids)) if ids else 0
        comp.completed = len(ids & completed)
        comp.total = len(ids)
        comp.level = (
            "Expert" if comp.score >= 90 else "Proficient" if comp.score >= 60
            else "Developing" if comp.score >= 25 else "Awareness" if comp.score > 0 else "Not started"
        )
        areas[comp.area].append(comp)
    return render(request, "courses/competencies.html", {
        "areas": dict(areas),
        "chart_labels": [c.name for c in comps],
        "chart_values": [c.score for c in comps],
    })


# ---------------------------------------------------------------- trainers

@trainer_required
def studio(request):
    courses = Course.objects.select_related("category")
    if not request.user.is_portal_admin:
        courses = courses.filter(instructor=request.user)
    courses = attach_course_stats(courses)
    completions = defaultdict(int)
    for cid in Enrollment.objects.filter(course_id__in=[c.pk for c in courses], completed_at__isnull=False).values_list("course_id", flat=True):
        completions[cid] += 1
    for c in courses:
        c.num_completed = completions[c.pk]
        c.completion_rate = round(c.num_completed * 100 / c.num_enrolled) if c.num_enrolled else 0
    return render(request, "courses/studio.html", {"courses": courses})


@trainer_required
def course_create(request):
    form = CourseForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        course = form.save(commit=False)
        course.instructor = request.user
        course.save()
        form.save_m2m()
        messages.success(request, "Course created. Now add modules and lessons.")
        return redirect("courses:manage", slug=course.slug)
    return render(request, "courses/course_form.html", {"form": form})


@trainer_required
def course_edit(request, slug):
    course = _managed_course(request, slug)
    form = CourseForm(request.POST or None, instance=course)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Course details saved.")
        return redirect("courses:manage", slug=course.slug)
    return render(request, "courses/course_form.html", {"form": form, "course": course})


@trainer_required
@require_POST
def course_delete(request, slug):
    course = _managed_course(request, slug)
    course.delete()
    messages.success(request, f"“{course.title}” was deleted.")
    return redirect("courses:studio")


@trainer_required
def course_manage(request, slug):
    course = _managed_course(request, slug)
    modules = list(course.modules.prefetch_related("lessons"))
    quizzes = list(course.quizzes.all())
    for quiz in quizzes:
        quiz.num_questions = quiz.questions.count()
        quiz.num_attempts = quiz.attempts.count()
    return render(request, "courses/manage.html", {
        "course": course,
        "modules": modules,
        "quizzes": quizzes,
        "module_form": ModuleForm(initial={"order": len(modules) + 1}),
    })


@trainer_required
def course_learners(request, slug):
    course = _managed_course(request, slug)
    enrollments = list(Enrollment.objects.filter(course=course).select_related("user"))
    quiz_ids = list(course.quizzes.values_list("id", flat=True))
    best = {}
    for uid, score in Attempt.objects.filter(quiz_id__in=quiz_ids).values_list("user_id", "score"):
        best[uid] = max(best.get(uid, 0), score)
    for e in enrollments:
        e.progress = progress_map(e.user, [course.pk])[course.pk]
        e.best_score = best.get(e.user_id)
    return render(request, "courses/learners.html", {"course": course, "enrollments": enrollments})


@trainer_required
@require_POST
def module_add(request, slug):
    course = _managed_course(request, slug)
    form = ModuleForm(request.POST)
    if form.is_valid():
        module = form.save(commit=False)
        module.course = course
        module.save()
        messages.success(request, f"Module “{module.title}” added.")
    return redirect("courses:manage", slug=slug)


@trainer_required
def module_edit(request, pk):
    module = get_object_or_404(Module.objects.select_related("course"), pk=pk)
    course = _managed_course(request, module.course.slug)
    form = ModuleForm(request.POST or None, instance=module)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Module updated.")
        return redirect("courses:manage", slug=course.slug)
    return render(request, "courses/simple_form.html", {
        "form": form, "course": course, "title": "Edit module", "back": course,
    })


@trainer_required
@require_POST
def module_delete(request, pk):
    module = get_object_or_404(Module.objects.select_related("course"), pk=pk)
    course = _managed_course(request, module.course.slug)
    module.delete()
    messages.success(request, "Module deleted.")
    return redirect("courses:manage", slug=course.slug)


@trainer_required
def lesson_form(request, module_pk=None, pk=None):
    lesson = get_object_or_404(Lesson.objects.select_related("module__course"), pk=pk) if pk else None
    module = lesson.module if lesson else get_object_or_404(Module.objects.select_related("course"), pk=module_pk)
    course = _managed_course(request, module.course.slug)
    initial = {} if lesson else {"order": module.lessons.count() + 1}
    form = LessonForm(request.POST or None, request.FILES or None, instance=lesson, initial=initial)
    if request.method == "POST" and form.is_valid():
        obj = form.save(commit=False)
        obj.module = module
        obj.save()
        messages.success(request, "Lesson saved.")
        return redirect("courses:manage", slug=course.slug)
    return render(request, "courses/lesson_form.html", {"form": form, "course": course, "module": module, "lesson": lesson})


@trainer_required
@require_POST
def lesson_delete(request, pk):
    lesson = get_object_or_404(Lesson.objects.select_related("module__course"), pk=pk)
    course = _managed_course(request, lesson.module.course.slug)
    lesson.delete()
    messages.success(request, "Lesson deleted.")
    return redirect("courses:manage", slug=course.slug)
