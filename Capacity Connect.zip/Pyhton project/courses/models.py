import re
import secrets

from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify


def unique_slug(model, title, instance_pk=None):
    base = slugify(title)[:60] or "item"
    slug, n = base, 2
    while model.objects.filter(slug=slug).exclude(pk=instance_pk).exists():
        slug = f"{base}-{n}"
        n += 1
    return slug


class Category(models.Model):
    name = models.CharField(max_length=80, unique=True)
    slug = models.SlugField(max_length=90, unique=True, blank=True)
    icon = models.CharField(max_length=40, default="book-open", help_text="Lucide icon name")
    color = models.CharField(max_length=7, default="#4f46e5")

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "categories"

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(Category, self.name, self.pk)
        super().save(*args, **kwargs)


class Competency(models.Model):
    name = models.CharField(max_length=80, unique=True)
    area = models.CharField(max_length=80, help_text="Competency area, e.g. Technical, Behavioural")
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["area", "name"]
        verbose_name_plural = "competencies"

    def __str__(self):
        return self.name


class Course(models.Model):
    class Level(models.TextChoices):
        BEGINNER = "beginner", "Beginner"
        INTERMEDIATE = "intermediate", "Intermediate"
        ADVANCED = "advanced", "Advanced"

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        PUBLISHED = "published", "Published"

    title = models.CharField(max_length=160)
    slug = models.SlugField(max_length=180, unique=True, blank=True)
    summary = models.CharField(max_length=255, help_text="One-line description shown on course cards")
    description = models.TextField(help_text="Full course overview. Supports simple markdown (## headings, - lists, **bold**).")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name="courses")
    instructor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="courses_taught")
    level = models.CharField(max_length=20, choices=Level.choices, default=Level.BEGINNER)
    duration_hours = models.PositiveIntegerField(default=2)
    competencies = models.ManyToManyField(Competency, blank=True, related_name="courses")
    outcomes = models.TextField(blank=True, help_text="Learning outcomes, one per line")
    is_mandatory = models.BooleanField(default=False, help_text="Mandatory training for all employees")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(Course, self.title, self.pk)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("courses:detail", args=[self.slug])

    @property
    def is_published(self):
        return self.status == self.Status.PUBLISHED

    @property
    def outcome_list(self):
        return [line.strip("-• ").strip() for line in self.outcomes.splitlines() if line.strip()]

    @property
    def color(self):
        return self.category.color if self.category else "#4f46e5"

    @property
    def icon(self):
        return self.category.icon if self.category else "book-open"

    def lessons(self):
        return Lesson.objects.filter(module__course=self)


class Module(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="modules")
    title = models.CharField(max_length=160)
    description = models.CharField(max_length=255, blank=True)
    order = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return f"{self.course} · {self.title}"


class Lesson(models.Model):
    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name="lessons")
    title = models.CharField(max_length=160)
    content = models.TextField(help_text="Supports simple markdown (## headings, - lists, **bold**, `code`).")
    video_url = models.URLField(blank=True, help_text="Optional YouTube or Vimeo link")
    attachment = models.FileField(upload_to="lesson_files/", blank=True)
    duration_minutes = models.PositiveIntegerField(default=10)
    order = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.title

    @property
    def embed_url(self):
        url = self.video_url
        if not url:
            return ""
        yt = re.search(r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([\w-]{11})", url)
        if yt:
            return f"https://www.youtube.com/embed/{yt.group(1)}"
        vimeo = re.search(r"vimeo\.com/(\d+)", url)
        if vimeo:
            return f"https://player.vimeo.com/video/{vimeo.group(1)}"
        return ""


class Enrollment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="enrollments")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="enrollments")
    enrolled_at = models.DateTimeField(default=timezone.now)
    completed_at = models.DateTimeField(null=True, blank=True)
    last_lesson = models.ForeignKey(Lesson, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")

    class Meta:
        ordering = ["-enrolled_at"]
        constraints = [models.UniqueConstraint(fields=["user", "course"], name="unique_enrollment")]

    def __str__(self):
        return f"{self.user} → {self.course}"

    @property
    def is_completed(self):
        return self.completed_at is not None


class LessonProgress(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="lesson_progress")
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name="progress")
    completed_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "lesson"], name="unique_lesson_progress")]


class Review(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="reviews")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveSmallIntegerField(choices=[(i, f"{i} star{'s' if i > 1 else ''}") for i in range(5, 0, -1)])
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-created_at"]
        constraints = [models.UniqueConstraint(fields=["course", "user"], name="unique_review")]


def certificate_code():
    return "CC-" + secrets.token_hex(4).upper()


class Certificate(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="certificates")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="certificates")
    code = models.CharField(max_length=20, unique=True, default=certificate_code)
    issued_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-issued_at"]
        constraints = [models.UniqueConstraint(fields=["user", "course"], name="unique_certificate")]

    def __str__(self):
        return f"{self.code} · {self.user} · {self.course}"

    def get_absolute_url(self):
        return reverse("courses:certificate", args=[self.code])
