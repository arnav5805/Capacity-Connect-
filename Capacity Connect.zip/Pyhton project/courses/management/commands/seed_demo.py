import math
import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import User
from assessments.models import Attempt, Choice, Question, Quiz
from core.models import Announcement
from courses.models import Category, Certificate, Competency, Course, Enrollment, Lesson, LessonProgress, Module, Review
from knowledge.models import Comment, Post

from . import _seed_data as data


class Command(BaseCommand):
    help = "Load demo users, courses, assessments and learning activity into Capacity Connect."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Delete existing portal data before seeding.")

    def handle(self, *args, **options):
        if User.objects.filter(username="admin").exists() and not options["reset"]:
            self.stdout.write(self.style.WARNING("Demo data already exists. Use --reset to wipe and reseed."))
            return
        if options["reset"]:
            self.wipe()
        rng = random.Random(2026)
        now = timezone.now()

        users = self.create_users()
        categories = {name: Category.objects.create(name=name, icon=icon, color=color) for name, icon, color in data.CATEGORIES}
        comps = {name: Competency.objects.create(name=name, area=area, description=desc) for name, area, desc in data.COMPETENCIES}
        courses = self.create_courses(users, categories, comps, now)
        self.simulate_activity(rng, users, courses, now)
        self.create_community(rng, users, now)

        self.stdout.write(self.style.SUCCESS(
            f"Seeded {User.objects.count()} users, {Course.objects.count()} courses, "
            f"{Lesson.objects.count()} lessons, {Question.objects.count()} questions, "
            f"{Enrollment.objects.count()} enrollments, {Certificate.objects.count()} certificates."
        ))
        self.stdout.write("Logins: admin/admin123 | priya/trainer123 | rohan/trainer123 | aarav/learner123 (all learners use learner123)")

    def wipe(self):
        for model in [Attempt, Choice, Question, Quiz, Certificate, Review, LessonProgress, Enrollment,
                      Lesson, Module, Course, Competency, Category, Comment, Post, Announcement, User]:
            model.objects.all().delete()
        self.stdout.write("Existing data removed.")

    def create_users(self):
        users = {}
        for i, (username, first, last, role, dept, title, password) in enumerate(data.USERS, start=1):
            user = User(
                username=username, first_name=first, last_name=last, role=role, department=dept,
                designation=title, email=f"{username}@capacityconnect.org", employee_id=f"EMP{1000 + i}",
                bio=f"{title} in {dept}. Passionate about continuous learning.",
            )
            if role == "admin":
                user.is_staff = user.is_superuser = True
            user.set_password(password)
            user.save()
            users[username] = user
        return users

    def create_courses(self, users, categories, comps, now):
        courses = []
        for idx, spec in enumerate(data.COURSES):
            course = Course.objects.create(
                title=spec["title"], summary=spec["summary"], description=spec["description"],
                outcomes=spec["outcomes"], category=categories[spec["category"]],
                instructor=users[spec["instructor"]], level=spec["level"], duration_hours=spec["hours"],
                is_mandatory=spec.get("mandatory", False), status=spec.get("status", "published"),
                created_at=now - timedelta(days=200 - idx * 12),
            )
            course.competencies.set([comps[c] for c in spec["competencies"]])
            for m_order, (m_title, lessons) in enumerate(spec["modules"], start=1):
                module = Module.objects.create(course=course, title=m_title, order=m_order)
                for l_order, (l_title, minutes, content) in enumerate(lessons, start=1):
                    Lesson.objects.create(module=module, title=l_title, content=content, duration_minutes=minutes, order=l_order)
            if spec["quiz"]:
                q_title, questions = spec["quiz"]
                quiz = Quiz.objects.create(
                    course=course, title=q_title, pass_mark=70 if spec.get("mandatory") else 60,
                    time_limit_minutes=max(5, len(questions) * 2), max_attempts=3,
                    description="Answer every question. Explanations are shown after you submit.",
                )
                for q_order, (text, options, correct, explanation) in enumerate(questions, start=1):
                    question = Question.objects.create(quiz=quiz, text=text, explanation=explanation, order=q_order)
                    for i, option in enumerate(options):
                        Choice.objects.create(question=question, text=option, is_correct=(i == correct))
            courses.append(course)
        return courses

    def simulate_activity(self, rng, users, courses, now):
        published = [c for c in courses if c.status == "published"]
        learners = [u for u in users.values() if u.role == "learner"]
        for user in learners:
            mandatory = [c for c in published if c.is_mandatory]
            optional = rng.sample([c for c in published if not c.is_mandatory], rng.randint(2, 4))
            for course in mandatory + optional:
                if course in mandatory and rng.random() < 0.15:
                    continue  # a few people haven't started mandatory training yet
                self.simulate_enrollment(rng, user, course, now, featured=user.username in ("aarav", "meera"))

    def simulate_enrollment(self, rng, user, course, now, featured=False):
        enrolled_at = now - timedelta(days=rng.randint(3 if featured else 5, 170), hours=rng.randint(0, 20))
        enrollment = Enrollment.objects.create(user=user, course=course, enrolled_at=enrolled_at)
        lessons = list(Lesson.objects.filter(module__course=course).order_by("module__order", "order"))
        quiz = course.quizzes.first()
        stage = rng.choice(["new", "partial", "partial", "lessons_done", "complete", "complete", "complete"])
        if featured and stage == "new":
            stage = "partial"
        count = {"new": 0, "partial": max(1, len(lessons) // 2), "lessons_done": len(lessons), "complete": len(lessons)}[stage]
        span = max((now - enrolled_at).days, 1)
        moment = enrolled_at
        for lesson in lessons[:count]:
            moment = min(moment + timedelta(days=rng.uniform(0.2, span / max(count, 1)), minutes=rng.randint(5, 90)), now)
            if featured and stage == "partial":
                moment = now - timedelta(days=rng.randint(0, 12), hours=rng.randint(0, 10))
            LessonProgress.objects.create(user=user, lesson=lesson, completed_at=moment)
        if count:
            enrollment.last_lesson = lessons[count - 1]
            enrollment.save(update_fields=["last_lesson"])
        if not quiz or stage in ("new", "partial"):
            return
        questions = list(quiz.questions.prefetch_related("choices"))
        tries = [rng.randint(70, 100)] if stage == "complete" else [rng.randint(25, 55)]
        if stage == "complete" and rng.random() < 0.3:
            tries.insert(0, rng.randint(30, 60))
        for score_target in tries:
            correct_n = round(len(questions) * score_target / 100)
            if stage != "complete":
                # stay below the pass mark, otherwise the course would be complete
                correct_n = min(correct_n, math.ceil(len(questions) * quiz.pass_mark / 100) - 1)
            answers, picked_correct = {}, 0
            for i, q in enumerate(questions):
                choices = list(q.choices.all())
                right = next(c for c in choices if c.is_correct)
                pick = right if i < correct_n else rng.choice([c for c in choices if not c.is_correct])
                answers[str(q.pk)] = str(pick.pk)
                picked_correct += pick.is_correct
            score = round(picked_correct * 100 / len(questions), 1)
            moment = min(moment + timedelta(hours=rng.randint(1, 48)), now)
            Attempt.objects.create(
                user=user, quiz=quiz, score=score, correct_count=picked_correct, total_questions=len(questions),
                passed=score >= quiz.pass_mark, answers=answers,
                started_at=moment - timedelta(minutes=rng.randint(3, 9), seconds=rng.randint(0, 59)), submitted_at=moment,
            )
        if stage == "complete" and Attempt.objects.filter(user=user, quiz=quiz, passed=True).exists():
            enrollment.completed_at = moment
            enrollment.save(update_fields=["completed_at"])
            Certificate.objects.create(user=user, course=course, issued_at=moment)
            if rng.random() < 0.75:
                Review.objects.create(
                    course=course, user=user, rating=rng.choice([4, 5, 5, 5, 4, 3]),
                    comment=rng.choice(data.REVIEW_COMMENTS), created_at=moment + timedelta(hours=1),
                )

    def create_community(self, rng, users, now):
        everyone = list(users.values())
        posts = []
        for i, (author, kind, title, tags, body, *_) in enumerate(data.POSTS):
            post = Post.objects.create(
                author=users[author], kind=kind, title=title, tags=tags, body=body,
                views=rng.randint(12, 140), created_at=now - timedelta(days=40 - i * 5, hours=rng.randint(0, 12)),
            )
            post.likes.set(rng.sample(everyone, rng.randint(2, 8)))
            posts.append(post)
        for author, post_idx, body in data.COMMENTS:
            Comment.objects.create(
                post=posts[post_idx], author=users[author], body=body,
                created_at=posts[post_idx].created_at + timedelta(hours=rng.randint(2, 60)),
            )
        for i, (title, priority, body) in enumerate(data.ANNOUNCEMENTS):
            Announcement.objects.create(
                title=title, priority=priority, body=body, author=users["admin" if i == 0 else "priya"],
                created_at=now - timedelta(days=i * 4 + 1),
            )
