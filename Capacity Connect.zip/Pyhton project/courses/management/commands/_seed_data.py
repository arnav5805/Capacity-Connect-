"""Demo content for `python manage.py seed_demo`."""

CATEGORIES = [
    ("Leadership & Management", "users", "#7c3aed"),
    ("Digital Skills", "monitor-smartphone", "#2563eb"),
    ("Data & Analytics", "bar-chart-3", "#0891b2"),
    ("Communication", "message-circle", "#db2777"),
    ("Compliance & Ethics", "shield-check", "#059669"),
    ("Project Management", "kanban", "#d97706"),
]

COMPETENCIES = [
    ("Data Literacy", "Technical", "Read, interpret and question data to support decisions."),
    ("Data Visualisation", "Technical", "Present data clearly with the right charts and dashboards."),
    ("Digital Productivity", "Technical", "Use cloud and collaboration tools efficiently."),
    ("Cyber Hygiene", "Technical", "Protect information and devices against everyday threats."),
    ("Communication", "Behavioural", "Convey ideas clearly in writing, speech and meetings."),
    ("Leadership", "Behavioural", "Set direction, motivate people and develop talent."),
    ("Collaboration", "Behavioural", "Work effectively across teams and functions."),
    ("Problem Solving", "Behavioural", "Structure problems and reach evidence-based solutions."),
    ("Project Planning", "Functional", "Plan, track and deliver work predictably."),
    ("Regulatory Compliance", "Functional", "Understand and apply policies, laws and ethics."),
]

USERS = [
    # username, first, last, role, department, designation, password
    ("admin", "Kavita", "Rao", "admin", "Training & Development", "Head of Learning & Development", "admin123"),
    ("priya", "Priya", "Sharma", "trainer", "Training & Development", "Senior Corporate Trainer", "trainer123"),
    ("rohan", "Rohan", "Mehta", "trainer", "Information Technology", "Data & Analytics Lead", "trainer123"),
    ("aarav", "Aarav", "Patel", "learner", "Sales & Marketing", "Sales Executive", "learner123"),
    ("meera", "Meera", "Iyer", "learner", "Finance", "Accounts Officer", "learner123"),
    ("kabir", "Kabir", "Singh", "learner", "Information Technology", "Software Engineer", "learner123"),
    ("ananya", "Ananya", "Gupta", "learner", "Human Resources", "HR Associate", "learner123"),
    ("vikram", "Vikram", "Nair", "learner", "Operations", "Operations Manager", "learner123"),
    ("sneha", "Sneha", "Kulkarni", "learner", "Research & Development", "Research Analyst", "learner123"),
    ("arjun", "Arjun", "Reddy", "learner", "Administration", "Administrative Officer", "learner123"),
    ("fatima", "Fatima", "Khan", "learner", "Sales & Marketing", "Marketing Specialist", "learner123"),
    ("dev", "Dev", "Malhotra", "learner", "Finance", "Financial Analyst", "learner123"),
    ("isha", "Isha", "Joshi", "learner", "Information Technology", "QA Engineer", "learner123"),
    ("rahul", "Rahul", "Verma", "learner", "Operations", "Logistics Coordinator", "learner123"),
    ("nisha", "Nisha", "Bose", "learner", "Human Resources", "Talent Acquisition Specialist", "learner123"),
]

COURSES = [
    {
        "title": "Data Analytics Essentials",
        "category": "Data & Analytics", "instructor": "rohan", "level": "beginner", "hours": 6,
        "competencies": ["Data Literacy", "Data Visualisation", "Problem Solving"],
        "summary": "Turn raw numbers into insight — the core concepts every professional needs to work confidently with data.",
        "description": "Data is now part of every role. This course builds a practical foundation in **data literacy**: how data is collected, cleaned, summarised and visualised, and how to avoid the most common mistakes when drawing conclusions.\n\n## Who is this for?\n- Anyone who reads reports or dashboards\n- Team leads who make data-driven decisions\n- New analysts who want a structured starting point",
        "outcomes": "Explain the data lifecycle from collection to decision\nCalculate and interpret key descriptive statistics\nChoose the right chart for your message\nSpot misleading data and common biases",
        "modules": [
            ("Foundations of Data", [
                ("Why data literacy matters", 10, "## Data in everyday work\nEvery department produces data — sales pipelines, attendance logs, budgets, survey results. **Data literacy** is the ability to read, work with, analyse and argue with data.\n\n## The data lifecycle\n1. Collect — capture data from systems, forms and sensors\n2. Clean — fix errors, duplicates and missing values\n3. Analyse — summarise and find patterns\n4. Communicate — share insights with the right audience\n5. Decide — act, then measure the result\n\n> Good decisions come from good questions. Always start with *what decision will this data support?*"),
                ("Types of data", 12, "## Qualitative vs quantitative\n- **Qualitative (categorical):** department, product type, feedback theme\n- **Quantitative (numeric):** revenue, hours trained, test scores\n\n## Levels of measurement\n- **Nominal** — labels with no order (city)\n- **Ordinal** — ordered categories (satisfaction: low/medium/high)\n- **Interval / Ratio** — numeric with meaningful differences\n\nKnowing the type tells you which summaries and charts make sense. You can average test scores, but not department names!"),
                ("Cleaning data", 15, "## Garbage in, garbage out\nMost analysis time goes into preparing data. Common issues:\n- Duplicate records\n- Missing values\n- Inconsistent formats (`01/02/2025` vs `2025-02-01`)\n- Outliers caused by typing errors\n\n## A simple cleaning checklist\n1. Remove exact duplicates\n2. Standardise formats and units\n3. Decide how to treat blanks — remove, fill, or flag\n4. Investigate extreme values before deleting them\n\n> Always keep a copy of the raw data and document every cleaning step."),
            ]),
            ("Analysing Data", [
                ("Descriptive statistics", 15, "## Measures of centre\n- **Mean** — the arithmetic average; sensitive to outliers\n- **Median** — the middle value; robust for skewed data like salaries\n- **Mode** — the most frequent value\n\n## Measures of spread\n- **Range** — max minus min\n- **Standard deviation** — typical distance from the mean\n\nExample: two teams both average 75% on a test. Team A ranges 70–80%, Team B ranges 40–100%. Same mean, very different stories."),
                ("Correlation is not causation", 10, "## Beware of false conclusions\nTwo variables moving together does **not** mean one causes the other. Ice-cream sales and sunburn both rise in summer — the hidden factor is temperature.\n\n## Questions to ask\n- Could a third factor explain both?\n- Could the direction be reversed?\n- Is the sample large and representative?\n\n> Use experiments or controlled comparisons when you need to prove cause and effect."),
            ]),
            ("Communicating Insights", [
                ("Choosing the right chart", 12, "## Match the chart to the message\n- **Comparison** → bar chart\n- **Trend over time** → line chart\n- **Part of a whole** → stacked bar or (sparingly) a pie\n- **Relationship** → scatter plot\n- **Distribution** → histogram\n\n## Design tips\n- One message per chart\n- Label axes and units\n- Start bar charts at zero\n- Use colour to highlight, not decorate"),
                ("Telling a story with data", 10, "## The insight sandwich\n1. **Context** — what question were we answering?\n2. **Insight** — what did we find? (one sentence)\n3. **Action** — what should we do next?\n\nKeep the audience in mind: executives want the decision, specialists want the method. Put detail in an appendix, not on the main slide."),
            ]),
        ],
        "quiz": ("Data Analytics Essentials — Final Assessment", [
            ("Which measure of centre is most robust to extreme outliers?", ["Mean", "Median", "Range", "Standard deviation"], 1, "The median is the middle value, so a few extreme values barely move it."),
            ("Department names are an example of which level of measurement?", ["Ratio", "Interval", "Nominal", "Ordinal"], 2, "Nominal data are labels with no inherent order."),
            ("What is the best chart for showing a trend over 12 months?", ["Pie chart", "Line chart", "Scatter plot", "Histogram"], 1, "Line charts emphasise change over continuous time."),
            ("Ice-cream sales and sunburn rates are correlated. What is the most likely explanation?", ["Ice cream causes sunburn", "Sunburn causes ice-cream cravings", "A third factor (hot weather) drives both", "The data must be wrong"], 2, "Hot weather is a confounding variable that influences both."),
            ("What should you do FIRST before cleaning a dataset?", ["Delete all outliers", "Keep a copy of the raw data", "Fill blanks with zeros", "Build a dashboard"], 1, "Preserving raw data lets you audit and redo cleaning steps."),
        ]),
    },
    {
        "title": "Cybersecurity Awareness for Everyone",
        "category": "Compliance & Ethics", "instructor": "priya", "level": "beginner", "hours": 2, "mandatory": True,
        "competencies": ["Cyber Hygiene", "Regulatory Compliance"],
        "summary": "Mandatory annual training: recognise phishing, protect passwords and keep organisational data safe.",
        "description": "Most security incidents start with a single click. This **mandatory** course equips every employee to recognise and respond to everyday cyber threats.\n\nComplete all lessons and pass the assessment (70%) to stay compliant.",
        "outcomes": "Identify phishing and social-engineering attempts\nCreate and manage strong passwords with MFA\nHandle sensitive data according to policy\nReport incidents quickly and correctly",
        "modules": [
            ("Recognising Threats", [
                ("Phishing and social engineering", 12, "## What is phishing?\nPhishing messages pretend to come from a trusted source to trick you into clicking a link, opening an attachment or sharing credentials.\n\n## Red flags\n- Urgency: *“Your account will be closed in 2 hours!”*\n- Mismatched sender address or look-alike domains\n- Unexpected attachments or invoice requests\n- Requests for passwords or OTPs — **IT will never ask for these**\n\n> When in doubt, don't click. Verify through a known phone number or the official portal."),
                ("Malware and safe browsing", 10, "## How malware gets in\n- Infected attachments and downloads\n- Fake software updates and browser pop-ups\n- Unknown USB drives\n\n## Safe habits\n- Install software only from approved sources\n- Keep your OS and browser updated\n- Lock your screen (`Win + L`) whenever you step away"),
            ]),
            ("Protecting Information", [
                ("Passwords and multi-factor authentication", 10, "## Strong passwords\nUse long **passphrases** — e.g. *Monsoon-Tea-Bicycle-42* — rather than short complex strings. Never reuse work passwords elsewhere.\n\n## Multi-factor authentication (MFA)\nMFA adds a second proof such as an authenticator app code. Even if a password leaks, MFA blocks most account takeovers.\n\n- Use the approved password manager\n- Never share OTPs, even with colleagues"),
                ("Data classification and reporting incidents", 12, "## Classify before you share\n- **Public** — website content\n- **Internal** — policies, org charts\n- **Confidential** — employee, financial and client data\n\nConfidential data must only be shared through approved, encrypted channels.\n\n## Report fast\nIf you clicked a suspicious link or lost a device, report it to the IT helpdesk **immediately**. Fast reporting limits the damage — you will not be blamed for reporting."),
            ]),
        ],
        "quiz": ("Cybersecurity Awareness Check", [
            ("An email says your mailbox will be deleted in 1 hour unless you log in via the link. What should you do?", ["Click the link quickly", "Forward it to all colleagues", "Do not click; verify via the official portal and report it", "Reply asking if it is genuine"], 2, "Urgency plus a login link is a classic phishing pattern."),
            ("Which is the strongest password approach?", ["P@ss1", "Your birth date", "A long, unique passphrase plus MFA", "The same strong password for all sites"], 2, "Length, uniqueness and MFA together give the best protection."),
            ("IT support calls asking for your OTP to “fix your account”. You should:", ["Share it — they're IT", "Refuse and report the call", "Share only half the code", "Email it instead"], 1, "Legitimate IT staff never ask for your OTP."),
            ("Employee salary data is classified as:", ["Public", "Internal", "Confidential", "Unclassified"], 2, "Personal and financial data is confidential."),
        ]),
    },
    {
        "title": "Effective Workplace Communication",
        "category": "Communication", "instructor": "priya", "level": "beginner", "hours": 3,
        "competencies": ["Communication", "Collaboration"],
        "summary": "Write clearer emails, run better meetings and give feedback that people actually act on.",
        "description": "Clear communication saves time, prevents conflict and builds trust. This practical course covers **written, verbal and feedback** skills you can apply the same day.",
        "outcomes": "Write concise, action-oriented emails\nPlan and facilitate productive meetings\nPractise active listening\nGive and receive feedback using the SBI model",
        "modules": [
            ("Clear Writing", [
                ("Writing emails that get answered", 10, "## Lead with the ask\nPut the request or key point in the **first two lines**. Busy readers skim.\n\n## Structure\n- A specific subject line: *“Approval needed: Q3 training budget by Fri”*\n- Context in 2–3 sentences\n- Bullet points for options or steps\n- A clear deadline and owner\n\n> If an email needs more than three scrolls, consider a call or a document instead."),
                ("Plain language", 8, "## Say it simply\n- Prefer short words: *use* not *utilise*\n- One idea per sentence\n- Active voice: *“The team approved the plan”*\n- Explain acronyms the first time\n\nPlain language is not “dumbing down” — it respects the reader's time."),
            ]),
            ("Conversations & Meetings", [
                ("Active listening", 10, "## Listen to understand\n- Give full attention — close the laptop\n- Paraphrase: *“So what you're saying is…”*\n- Ask open questions: *what, how, tell me more*\n- Notice tone and body language\n\nActive listening reduces misunderstandings and makes people feel valued."),
                ("Running productive meetings", 12, "## Before\n- Is a meeting really needed?\n- Share an agenda with desired outcomes\n\n## During\n- Start on time, assign a note-taker\n- Timebox each topic\n\n## After\n- Send actions with **owner + due date** within 24 hours"),
                ("Giving feedback with SBI", 12, "## The SBI model\n- **Situation** — when and where\n- **Behaviour** — what you observed (facts, not judgements)\n- **Impact** — the effect it had\n\nExample: *“In yesterday's client call (S), you summarised the action items clearly (B), and the client confirmed next steps immediately (I).”*\n\n> Feedback should be timely, specific and frequent — positive as well as developmental."),
            ]),
        ],
        "quiz": ("Workplace Communication Quiz", [
            ("Where should the main request be placed in a work email?", ["In the last paragraph", "In the first two lines", "In an attachment", "In the signature"], 1, "Readers skim — lead with the ask."),
            ("What does SBI stand for?", ["Summary, Background, Idea", "Situation, Behaviour, Impact", "Speak, Breathe, Inform", "Strategy, Budget, Implementation"], 1, "Situation–Behaviour–Impact keeps feedback factual and specific."),
            ("Which is an example of active listening?", ["Checking messages while they talk", "Paraphrasing what you heard", "Preparing your reply while they speak", "Interrupting to save time"], 1, "Paraphrasing confirms understanding."),
            ("Meeting actions should be sent with:", ["An owner and due date", "Only the meeting title", "A long transcript", "No follow-up"], 0, "Clear ownership and dates drive accountability."),
        ]),
    },
    {
        "title": "Leading High-Performance Teams",
        "category": "Leadership & Management", "instructor": "priya", "level": "intermediate", "hours": 5,
        "competencies": ["Leadership", "Collaboration", "Problem Solving"],
        "summary": "Build trust, set clear goals and coach your team to consistently deliver excellent results.",
        "description": "Great teams don't happen by accident. This course gives new and experienced managers practical frameworks for **trust, goal-setting, coaching and delegation**.",
        "outcomes": "Build psychological safety in your team\nSet SMART goals and OKRs\nCoach using the GROW model\nDelegate effectively using the right level of autonomy",
        "modules": [
            ("Foundations of Team Performance", [
                ("Psychological safety", 12, "## The #1 predictor of team success\nResearch on high-performing teams consistently finds that **psychological safety** — the belief that you won't be punished for speaking up — matters most.\n\n## How leaders build it\n- Admit your own mistakes openly\n- Ask for input before giving yours\n- Respond to bad news with curiosity, not blame\n- Thank people for raising concerns"),
                ("Setting goals with SMART and OKRs", 15, "## SMART goals\n**S**pecific, **M**easurable, **A**chievable, **R**elevant, **T**ime-bound.\n\n## OKRs\n- **Objective:** an inspiring qualitative goal\n- **Key Results:** 2–4 measurable outcomes\n\nExample: *Objective — Make onboarding a great experience. KR1 — New-joiner satisfaction ≥ 4.5/5. KR2 — Time to productivity reduced from 8 to 5 weeks.*"),
            ]),
            ("Developing People", [
                ("Coaching with the GROW model", 15, "## GROW\n1. **Goal** — what do you want to achieve?\n2. **Reality** — where are you now?\n3. **Options** — what could you do?\n4. **Will** — what will you do, and by when?\n\nCoaching means asking more than telling. Your aim is to help people find their own solutions."),
                ("Delegation that develops", 12, "## Levels of delegation\n1. Do as I say\n2. Research and report back\n3. Recommend a decision\n4. Decide and inform me\n5. Act independently\n\nMatch the level to the person's skill and confidence, and increase autonomy over time.\n\n> Delegating is not dumping. Explain the *why*, agree checkpoints and stay available."),
            ]),
        ],
        "quiz": ("Team Leadership Assessment", [
            ("What does the “W” in the GROW coaching model stand for?", ["Why", "Will (way forward)", "Work", "Wins"], 1, "Will — commitment to specific actions and timing."),
            ("Which behaviour BEST builds psychological safety?", ["Blaming quickly to set standards", "Admitting your own mistakes", "Making all decisions alone", "Avoiding difficult topics"], 1, "Leaders modelling vulnerability makes it safe for others to speak up."),
            ("In an OKR, Key Results should be:", ["Vague and inspirational", "Measurable outcomes", "A list of tasks", "Unlimited in number"], 1, "Objectives inspire; Key Results measure."),
            ("A new team member lacks experience with a task. Which delegation level fits best initially?", ["Act independently", "Decide and inform me", "Research and report back", "No delegation ever"], 2, "Start with lower autonomy and increase it as capability grows."),
        ]),
    },
    {
        "title": "Agile Project Management Fundamentals",
        "category": "Project Management", "instructor": "rohan", "level": "intermediate", "hours": 4,
        "competencies": ["Project Planning", "Collaboration"],
        "summary": "Plan and deliver work iteratively with Scrum, Kanban and practical agile ceremonies.",
        "description": "Agile methods help teams deliver value early and adapt to change. Learn the **principles, roles and ceremonies** of Scrum and Kanban, and how to apply them beyond software.",
        "outcomes": "Explain agile values and principles\nDescribe Scrum roles, events and artefacts\nVisualise and limit work with Kanban\nWrite user stories with acceptance criteria",
        "modules": [
            ("Agile Mindset", [
                ("Agile values and principles", 10, "## The Agile Manifesto values\n- **Individuals and interactions** over processes and tools\n- **Working results** over comprehensive documentation\n- **Customer collaboration** over contract negotiation\n- **Responding to change** over following a plan\n\nThe items on the right still matter — agile simply values the left more."),
                ("Writing user stories", 12, "## Format\n*As a* [user], *I want* [goal], *so that* [benefit].\n\nExample: *As a learner, I want to download my certificate, so that I can share it with my manager.*\n\n## Acceptance criteria\nList the conditions that must be true for the story to be done — they make testing and agreement easy."),
            ]),
            ("Frameworks in Practice", [
                ("Scrum essentials", 15, "## Roles\n- **Product Owner** — maximises value, owns the backlog\n- **Scrum Master** — coaches the team, removes impediments\n- **Developers** — build the increment\n\n## Events\nSprint (1–4 weeks) · Sprint Planning · Daily Scrum (15 min) · Sprint Review · Retrospective\n\n## Artefacts\nProduct Backlog · Sprint Backlog · Increment"),
                ("Kanban and flow", 12, "## Visualise the work\nA Kanban board shows columns such as **To do → In progress → Review → Done**.\n\n## Limit work in progress (WIP)\nWIP limits stop teams from starting too much and finishing too little. Focus on **flow**: how quickly items move from start to done (cycle time)."),
            ]),
        ],
        "quiz": ("Agile Fundamentals Quiz", [
            ("Who is responsible for maximising the value of the product and ordering the backlog?", ["Scrum Master", "Product Owner", "Project sponsor", "Developers"], 1, "The Product Owner owns and orders the Product Backlog."),
            ("What is the maximum recommended length of the Daily Scrum?", ["5 minutes", "15 minutes", "30 minutes", "1 hour"], 1, "The Daily Scrum is time-boxed to 15 minutes."),
            ("What is the main purpose of WIP limits in Kanban?", ["Increase multitasking", "Improve flow by finishing work before starting more", "Track employee hours", "Replace planning"], 1, "Limiting WIP reduces context switching and improves flow."),
            ("Which is a correctly formatted user story?", ["Build a login page", "As a user, I want to reset my password, so that I can regain access", "Password reset — high priority", "Fix bug #231"], 1, "User stories describe who, what and why."),
        ]),
    },
    {
        "title": "Digital Productivity with Cloud Tools",
        "category": "Digital Skills", "instructor": "rohan", "level": "beginner", "hours": 3,
        "competencies": ["Digital Productivity", "Collaboration"],
        "summary": "Collaborate in real time, organise files and automate routine tasks with modern cloud tools.",
        "description": "Work smarter, not harder. Learn how to use cloud documents, shared drives, calendars and simple automation to **save hours every week**.",
        "outcomes": "Co-author documents in real time\nOrganise shared drives with clear conventions\nManage your calendar and focus time\nAutomate repetitive tasks with simple workflows",
        "modules": [
            ("Collaborate in the Cloud", [
                ("Real-time co-authoring", 10, "## Stop emailing attachments\nShare a **link** to a single cloud document so everyone edits the same version.\n\n- Use comments and @mentions for questions\n- Use *suggesting* mode for reviews\n- Check version history instead of saving *final_v7_FINAL.docx*"),
                ("Organising shared drives", 10, "## Naming conventions\n`YYYY-MM-DD_Project_DocumentType_v1`\n\n## Folder structure\n- Keep it shallow (max 3 levels)\n- Organise by function or project, not by person\n- Archive closed projects quarterly\n\n> A good structure means anyone can find a file in under 30 seconds."),
            ]),
            ("Work Smarter", [
                ("Calendar and focus time", 8, "## Protect deep work\n- Block 2-hour **focus time** slots weekly\n- Use 25- or 50-minute meetings to create buffers\n- Share your working hours and location\n\nBatch email and chat checks instead of reacting all day."),
                ("Automating routine tasks", 12, "## Look for repetition\nIf you do something more than three times a week, consider automating it.\n\n## Easy wins\n- Email rules to file newsletters\n- Form responses that update a spreadsheet automatically\n- Templates for recurring reports\n- Scheduled reminders for approvals"),
            ]),
        ],
        "quiz": ("Digital Productivity Check", [
            ("What is the best way to collaborate on a document with five colleagues?", ["Email attachments back and forth", "Share one cloud document link", "Print and annotate", "Each keeps their own copy"], 1, "A single shared document avoids version conflicts."),
            ("A good shared-drive folder structure should be:", ["Deep, with many nested levels", "Organised by individual names", "Shallow and organised by function or project", "One folder for everything"], 2, "Shallow, function-based structures are easiest to navigate."),
            ("Which task is the best candidate for automation?", ["A one-time strategic decision", "A weekly report you build manually every Monday", "A performance conversation", "Brainstorming ideas"], 1, "Repetitive, rules-based tasks are ideal for automation."),
        ]),
    },
    {
        "title": "Code of Conduct & Workplace Ethics",
        "category": "Compliance & Ethics", "instructor": "priya", "level": "beginner", "hours": 1, "mandatory": True,
        "competencies": ["Regulatory Compliance"],
        "summary": "Mandatory: understand our values, conflicts of interest, anti-harassment policy and how to speak up.",
        "description": "Our Code of Conduct guides how we behave with colleagues, partners and the public. This **mandatory** module explains key policies and the channels available to raise concerns safely.",
        "outcomes": "Apply the Code of Conduct to everyday decisions\nIdentify and declare conflicts of interest\nRecognise and prevent harassment\nUse speak-up channels confidently",
        "modules": [
            ("Our Code", [
                ("Integrity and conflicts of interest", 10, "## What is a conflict of interest?\nA situation where personal interests could influence — or appear to influence — your professional judgement.\n\n## Examples\n- Hiring a relative into your team\n- Accepting expensive gifts from a vendor\n- Holding shares in a supplier you evaluate\n\n> Declaring a conflict is not wrongdoing. **Hiding** one is."),
                ("Respectful workplace and speaking up", 12, "## Zero tolerance for harassment\nHarassment includes unwelcome conduct — verbal, physical, written or online — that creates an intimidating or offensive environment.\n\n## Speaking up\n- Talk to your manager or HR\n- Use the confidential ethics helpline\n- Retaliation against anyone who raises a concern in good faith is strictly prohibited"),
            ]),
        ],
        "quiz": ("Code of Conduct Acknowledgement Quiz", [
            ("A vendor offers you an expensive gift during a tender process. What should you do?", ["Accept it quietly", "Decline and inform your manager/compliance", "Accept and share with the team", "Ask for a bigger gift"], 1, "Gifts during procurement create a clear conflict of interest."),
            ("Declaring a potential conflict of interest is:", ["An admission of wrongdoing", "The correct and expected action", "Optional", "Only for senior staff"], 1, "Transparency protects you and the organisation."),
            ("Raising a concern in good faith that turns out to be unfounded will lead to:", ["Disciplinary action", "No retaliation — you are protected", "Automatic termination", "A salary cut"], 1, "Good-faith reporters are protected from retaliation."),
        ]),
    },
    {
        "title": "Advanced Excel for Reporting",
        "category": "Data & Analytics", "instructor": "rohan", "level": "advanced", "hours": 4, "status": "draft",
        "competencies": ["Data Literacy", "Digital Productivity"],
        "summary": "Pivot tables, XLOOKUP and dynamic dashboards for faster monthly reporting. (Coming soon)",
        "description": "This course is being prepared by the Data & Analytics team. It will cover **PivotTables, XLOOKUP, dynamic arrays and dashboard design**.",
        "outcomes": "Summarise large datasets with PivotTables\nCombine data with XLOOKUP\nBuild interactive dashboards",
        "modules": [
            ("PivotTables", [
                ("Building your first PivotTable", 15, "## Steps\n1. Format your data as a table (`Ctrl + T`)\n2. Insert → PivotTable\n3. Drag fields into Rows, Columns and Values\n\nPivotTables summarise thousands of rows in seconds."),
            ]),
        ],
        "quiz": None,
    },
]

POSTS = [
    ("meera", "tip", "5 Excel shortcuts that save me an hour every week", "excel, productivity, finance",
     "After moving to month-end reporting I collected the shortcuts I use most:\n\n- `Ctrl + T` — turn a range into a table\n- `Ctrl + Shift + L` — toggle filters\n- `Alt + =` — AutoSum\n- `Ctrl + ;` — insert today's date\n- `F4` — repeat last action / toggle absolute references\n\n> Tip: tables make formulas and pivots update automatically when you add rows."),
    ("kabir", "question", "How do you stay focused when working on deep technical tasks?", "focus, productivity, remote-work",
     "I keep getting pulled into chats and meetings. What strategies or tools do you use to protect focus time? Any team agreements that worked well?"),
    ("priya", "article", "Running retrospectives that actually change things", "agile, teams, leadership",
     "Many teams run retrospectives on autopilot. Here's a format that keeps them fresh:\n\n## 1. Set the stage (5 min)\nAsk everyone for one word that describes the sprint.\n\n## 2. Gather data (15 min)\nUse **Start / Stop / Continue** sticky notes.\n\n## 3. Decide (10 min)\nDot-vote and pick **one** improvement. Assign an owner.\n\n## 4. Follow up\nReview last retro's action at the start of the next one. If nothing changes, people stop sharing."),
    ("rohan", "resource", "Free datasets for practising data analysis", "data, analytics, learning",
     "If you completed **Data Analytics Essentials** and want to practise, public open-data portals are a great place to start. Look for datasets on:\n\n- Government open data portals\n- Public health statistics\n- Transport and mobility data\n\nPick a question first, then find data to answer it — not the other way round.",),
    ("ananya", "article", "Onboarding checklist for new joiners — what we learned", "hr, onboarding, teams",
     "HR reviewed feedback from 40 new joiners. The top three things that made onboarding great:\n\n1. **A buddy** in the first 30 days\n2. Access to systems and laptop **on day one**\n3. A clear 30-60-90 day plan\n\nManagers — please complete the onboarding checklist in the portal before your new hire's start date."),
    ("vikram", "tip", "Use the 2-minute rule to clear small tasks", "productivity, operations",
     "If a task takes less than two minutes, do it immediately instead of adding it to a list. It keeps the backlog clean and reduces mental load. Works great for approvals and quick replies."),
    ("sneha", "question", "Best way to present research findings to senior leadership?", "communication, data, presentations",
     "I have a detailed study with lots of charts. Leadership has 15 minutes. How do you decide what to keep and what to put in the appendix?"),
]

COMMENTS = [
    ("kabir", 0, "Didn't know about Ctrl + ; — super handy, thanks!"),
    ("dev", 0, "F4 for absolute references is a life saver in financial models."),
    ("priya", 1, "We agreed on 'no-meeting Wednesday mornings' as a team. Combined with status set to Do Not Disturb, it works really well."),
    ("isha", 1, "I block 2-hour focus slots in my calendar and close chat completely. The Digital Productivity course has a lesson on this too."),
    ("vikram", 2, "We tried the dot-voting step last sprint — much more focused discussion."),
    ("aarav", 4, "The buddy system made a huge difference for me when I joined."),
    ("rohan", 6, "Lead with the decision you need, then the one insight that supports it. Use the insight sandwich: context → insight → action."),
    ("fatima", 6, "One chart per key message, and rehearse it in under 10 minutes so there's time for questions."),
]

ANNOUNCEMENTS = [
    ("Annual cybersecurity training due by month-end", "urgent",
     "All employees must complete 'Cybersecurity Awareness for Everyone' and pass the assessment by the end of this month. Completion is tracked for compliance reporting."),
    ("New course: Leading High-Performance Teams", "important",
     "Managers and aspiring leaders — our new leadership course covering psychological safety, OKRs, GROW coaching and delegation is now live in the catalog."),
    ("Knowledge Hub is live!", "info",
     "Share tips, ask questions and learn from colleagues in the new Knowledge Hub. Every post earns you 15 points on the leaderboard."),
]

REVIEW_COMMENTS = [
    "Very practical — I used the ideas the same week.",
    "Clear explanations and a well-paced assessment.",
    "Great examples. Would love an advanced follow-up course.",
    "Short, focused and relevant to my role.",
    "The quiz explanations really helped reinforce the concepts.",
    "",
]
