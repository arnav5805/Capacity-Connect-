from django import forms

from core.forms import StyledFormMixin

from .models import Course, Lesson, Module, Review


class CourseForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            "title", "summary", "category", "level", "duration_hours", "status",
            "is_mandatory", "description", "outcomes", "competencies",
        ]
        widgets = {
            "competencies": forms.CheckboxSelectMultiple,
            "description": forms.Textarea(attrs={"rows": 8}),
            "outcomes": forms.Textarea(attrs={"rows": 4, "placeholder": "One outcome per line"}),
        }


class ModuleForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Module
        fields = ["title", "description", "order"]
        widgets = {
            "title": forms.TextInput(attrs={"placeholder": "Module title, e.g. Getting started"}),
            "description": forms.TextInput(attrs={"placeholder": "Short description (optional)"}),
            "order": forms.NumberInput(attrs={"placeholder": "Order", "min": 1}),
        }


class LessonForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ["title", "duration_minutes", "order", "video_url", "attachment", "content"]
        widgets = {"content": forms.Textarea(attrs={"rows": 14})}


class ReviewForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Review
        fields = ["rating", "comment"]
        widgets = {"comment": forms.Textarea(attrs={"rows": 3, "placeholder": "What did you find most useful?"})}
