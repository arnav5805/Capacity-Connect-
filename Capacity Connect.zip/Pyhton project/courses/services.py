"""Progress tracking and completion logic shared by courses and assessments."""
from collections import defaultdict

from django.utils import timezone

from .models import Certificate, Enrollment, Lesson, LessonProgress, Module, Review


def lesson_ids_by_course(course_ids):
    """{course_id: [lesson_id, ...]} using two flat queries (no nested joins)."""
    module_course = dict(Module.objects.filter(course_id__in=list(course_ids)).values_list("id", "course_id"))
    result = defaultdict(list)
    for lesson_id, module_id in Lesson.objects.filter(module_id__in=list(module_course)).values_list("id", "module_id"):
        result[module_course[module_id]].append(lesson_id)
    return result


def quiz_ids_by_course(course_ids):
    from assessments.models import Quiz

    result = defaultdict(list)
    for quiz_id, course_id in Quiz.objects.filter(course_id__in=list(course_ids)).values_list("id", "course_id"):
        result[course_id].append(quiz_id)
    return result


def passed_quiz_ids(user, quiz_ids=None):
    from assessments.models import Attempt

    qs = Attempt.objects.filter(user=user, passed=True)
    if quiz_ids is not None:
        qs = qs.filter(quiz_id__in=list(quiz_ids))
    return set(qs.values_list("quiz_id", flat=True))


def progress_map(user, course_ids):
    """{course_id: percent} — lessons completed + quizzes passed over total items."""
    course_ids = list(course_ids)
    lessons = lesson_ids_by_course(course_ids)
    quizzes = quiz_ids_by_course(course_ids)
    all_lessons = [lid for ids in lessons.values() for lid in ids]
    done_lessons = set(
        LessonProgress.objects.filter(user=user, lesson_id__in=all_lessons).values_list("lesson_id", flat=True)
    )
    done_quizzes = passed_quiz_ids(user, [qid for ids in quizzes.values() for qid in ids])
    result = {}
    for cid in course_ids:
        total = len(lessons[cid]) + len(quizzes[cid])
        done = len(done_lessons.intersection(lessons[cid])) + len(done_quizzes.intersection(quizzes[cid]))
        result[cid] = round(done * 100 / total) if total else 0
    return result


def course_progress(user, course):
    return progress_map(user, [course.pk])[course.pk]


def check_course_completion(user, course):
    """Mark the enrollment complete and issue a certificate once everything is done.

    Returns the newly issued Certificate, or None.
    """
    enrollment = Enrollment.objects.filter(user=user, course=course).first()
    if not enrollment or enrollment.is_completed:
        return None
    if course_progress(user, course) < 100:
        return None
    enrollment.completed_at = timezone.now()
    enrollment.save(update_fields=["completed_at"])
    certificate, _ = Certificate.objects.get_or_create(user=user, course=course)
    return certificate


def attach_course_stats(courses, user=None):
    """Annotate course objects in Python with enrolment, rating and lesson stats."""
    courses = list(courses)
    ids = [c.pk for c in courses]
    enrolled = defaultdict(int)
    for cid in Enrollment.objects.filter(course_id__in=ids).values_list("course_id", flat=True):
        enrolled[cid] += 1
    ratings = defaultdict(list)
    for cid, rating in Review.objects.filter(course_id__in=ids).values_list("course_id", "rating"):
        ratings[cid].append(rating)
    lessons = lesson_ids_by_course(ids)
    my_enrollments, progress = {}, {}
    if user is not None and user.is_authenticated:
        my_enrollments = {e.course_id: e for e in Enrollment.objects.filter(user=user, course_id__in=ids)}
        progress = progress_map(user, list(my_enrollments))
    for c in courses:
        c.num_enrolled = enrolled[c.pk]
        c.num_reviews = len(ratings[c.pk])
        c.rating = round(sum(ratings[c.pk]) / len(ratings[c.pk]), 1) if ratings[c.pk] else 0
        c.num_lessons = len(lessons[c.pk])
        c.my_enrollment = my_enrollments.get(c.pk)
        c.my_progress = progress.get(c.pk, 0)
    return courses
