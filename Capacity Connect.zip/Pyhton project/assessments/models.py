from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone

from courses.models import Course


class Quiz(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="quizzes")
    title = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    pass_mark = models.PositiveIntegerField(default=60, help_text="Minimum percentage needed to pass")
    time_limit_minutes = models.PositiveIntegerField(default=10, help_text="0 = no time limit")
    max_attempts = models.PositiveIntegerField(default=3, help_text="0 = unlimited attempts")
    shuffle_questions = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["created_at"]
        verbose_name_plural = "quizzes"

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("assessments:quiz", args=[self.pk])


class Question(models.Model):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name="questions")
    text = models.TextField()
    explanation = models.TextField(blank=True, help_text="Shown to learners after they submit")
    points = models.PositiveIntegerField(default=1)
    order = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.text[:80]


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="choices")
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.text


class Attempt(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="attempts")
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name="attempts")
    score = models.FloatField(default=0)
    correct_count = models.PositiveIntegerField(default=0)
    total_questions = models.PositiveIntegerField(default=0)
    passed = models.BooleanField(default=False)
    answers = models.JSONField(default=dict, blank=True)  # {question_id: choice_id}
    started_at = models.DateTimeField(default=timezone.now)
    submitted_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-submitted_at"]

    def __str__(self):
        return f"{self.user} · {self.quiz} · {self.score:.0f}%"

    @property
    def duration_display(self):
        seconds = int((self.submitted_at - self.started_at).total_seconds())
        return f"{seconds // 60}m {seconds % 60:02d}s"
