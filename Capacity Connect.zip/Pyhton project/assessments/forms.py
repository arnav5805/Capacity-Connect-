from django import forms

from core.forms import StyledFormMixin

from .models import Quiz


class QuizForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ["title", "description", "pass_mark", "time_limit_minutes", "max_attempts", "shuffle_questions"]
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}


class QuestionForm(StyledFormMixin, forms.Form):
    text = forms.CharField(label="Question", widget=forms.Textarea(attrs={"rows": 3}))
    choice_1 = forms.CharField(label="Option A", max_length=255)
    choice_2 = forms.CharField(label="Option B", max_length=255)
    choice_3 = forms.CharField(label="Option C", max_length=255, required=False)
    choice_4 = forms.CharField(label="Option D", max_length=255, required=False)
    correct = forms.ChoiceField(
        label="Correct answer",
        choices=[("1", "Option A"), ("2", "Option B"), ("3", "Option C"), ("4", "Option D")],
    )
    explanation = forms.CharField(required=False, widget=forms.Textarea(attrs={"rows": 2}),
                                  help_text="Shown after submission to reinforce learning")
    points = forms.IntegerField(min_value=1, max_value=10, initial=1)

    def clean(self):
        data = super().clean()
        correct = data.get("correct")
        if correct and not data.get(f"choice_{correct}"):
            self.add_error("correct", "The correct answer must be one of the options you filled in.")
        return data
