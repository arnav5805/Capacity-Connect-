from django.urls import path

from . import views

app_name = "assessments"

urlpatterns = [
    path("", views.my_assessments, name="mine"),
    path("<oid:pk>/", views.quiz_detail, name="quiz"),
    path("<oid:pk>/take/", views.quiz_take, name="take"),
    path("attempts/<oid:pk>/", views.attempt_result, name="result"),
    path("new/<slug:slug>/", views.quiz_create, name="create"),
    path("<oid:pk>/builder/", views.quiz_builder, name="builder"),
    path("<oid:pk>/delete/", views.quiz_delete, name="delete"),
    path("questions/<oid:pk>/delete/", views.question_delete, name="question_delete"),
]
