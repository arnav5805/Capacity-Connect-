import random
from datetime import datetime

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from accounts.decorators import can_manage_course, trainer_required
from courses.models import Course, Enrollment
from courses.services import check_course_completion

from .forms import QuestionForm, QuizForm
from .models import Attempt, Choice, Question, Quiz


def _can_take(user, quiz):
    return Enrollment.objects.filter(user=user, course=quiz.course).exists()


def _managed_quiz(request, pk):
    quiz = get_object_or_404(Quiz.objects.select_related("course"), pk=pk)
    if not can_manage_course(request.user, quiz.course):
        raise PermissionDenied
    return quiz


@login_required
def my_assessments(request):
    enrolled = list(Enrollment.objects.filter(user=request.user).values_list("course_id", flat=True))
    quizzes = list(Quiz.objects.filter(course_id__in=enrolled).select_related("course"))
    attempts = list(Attempt.objects.filter(user=request.user).select_related("quiz", "quiz__course"))
    for quiz in quizzes:
        mine = [a for a in attempts if a.quiz_id == quiz.pk]
        quiz.best = max((a.score for a in mine), default=None)
        quiz.passed = any(a.passed for a in mine)
        quiz.num_attempts = len(mine)
    scores = [a.score for a in attempts]
    return render(request, "assessments/my_assessments.html", {
        "pending": [q for q in quizzes if not q.passed],
        "passed": [q for q in quizzes if q.passed],
        "attempts": attempts[:15],
        "avg_score": round(sum(scores) / len(scores)) if scores else None,
        "pass_rate": round(sum(a.passed for a in attempts) * 100 / len(attempts)) if attempts else None,
        "chart_labels": [a.submitted_at.strftime("%d %b") for a in reversed(attempts[:10])],
        "chart_values": [round(a.score) for a in reversed(attempts[:10])],
    })


@login_required
def quiz_detail(request, pk):
    quiz = get_object_or_404(Quiz.objects.select_related("course"), pk=pk)
    manager = can_manage_course(request.user, quiz.course)
    if not manager and not _can_take(request.user, quiz):
        messages.info(request, "Enroll in the course to take this assessment.")
        return redirect(quiz.course)
    attempts = list(Attempt.objects.filter(user=request.user, quiz=quiz))
    remaining = None if quiz.max_attempts == 0 else max(quiz.max_attempts - len(attempts), 0)
    return render(request, "assessments/quiz_detail.html", {
        "quiz": quiz,
        "num_questions": quiz.questions.count(),
        "total_points": sum(quiz.questions.values_list("points", flat=True)),
        "attempts": attempts,
        "best": max((a.score for a in attempts), default=None),
        "passed": any(a.passed for a in attempts),
        "remaining": remaining,
        "can_attempt": (remaining is None or remaining > 0) and quiz.questions.exists() and _can_take(request.user, quiz),
        "is_manager": manager,
    })


@login_required
def quiz_take(request, pk):
    quiz = get_object_or_404(Quiz.objects.select_related("course"), pk=pk)
    if not _can_take(request.user, quiz):
        raise PermissionDenied
    used = Attempt.objects.filter(user=request.user, quiz=quiz).count()
    if quiz.max_attempts and used >= quiz.max_attempts:
        messages.error(request, "You have used all attempts for this assessment.")
        return redirect(quiz)
    questions = list(quiz.questions.prefetch_related("choices"))
    if not questions:
        messages.info(request, "This assessment has no questions yet.")
        return redirect(quiz)
    session_key = f"quiz_start_{quiz.pk}"

    if request.method == "POST":
        started = request.session.pop(session_key, None)
        started_at = datetime.fromisoformat(started) if started else timezone.now()
        answers, earned, total, correct = {}, 0, 0, 0
        for q in questions:
            total += q.points
            picked = request.POST.get(f"q_{q.pk}")
            right = next((c for c in q.choices.all() if c.is_correct), None)
            if picked:
                answers[str(q.pk)] = picked
            if right and picked == str(right.pk):
                earned += q.points
                correct += 1
        score = round(earned * 100 / total, 1) if total else 0
        attempt = Attempt.objects.create(
            user=request.user, quiz=quiz, score=score, correct_count=correct,
            total_questions=len(questions), passed=score >= quiz.pass_mark,
            answers=answers, started_at=started_at, submitted_at=timezone.now(),
        )
        certificate = check_course_completion(request.user, quiz.course) if attempt.passed else None
        if certificate:
            messages.success(request, f"🎉 You passed and completed “{quiz.course.title}”! Your certificate is ready.")
        elif attempt.passed:
            messages.success(request, f"Well done — you passed with {score:.0f}%.")
        else:
            messages.warning(request, f"You scored {score:.0f}%. The pass mark is {quiz.pass_mark}%. Review and try again.")
        return redirect("assessments:result", pk=attempt.pk)

    request.session[session_key] = timezone.now().isoformat()
    if quiz.shuffle_questions:
        random.shuffle(questions)
    for q in questions:
        q.choice_list = list(q.choices.all())
    return render(request, "assessments/quiz_take.html", {
        "quiz": quiz, "questions": questions, "attempt_number": used + 1,
        "time_limit_seconds": quiz.time_limit_minutes * 60,
    })


@login_required
def attempt_result(request, pk):
    attempt = get_object_or_404(Attempt.objects.select_related("quiz", "quiz__course", "user"), pk=pk)
    if attempt.user != request.user and not can_manage_course(request.user, attempt.quiz.course):
        raise PermissionDenied
    review = []
    for q in attempt.quiz.questions.prefetch_related("choices"):
        picked = attempt.answers.get(str(q.pk))
        choices = [
            {"text": c.text, "is_correct": c.is_correct, "picked": picked == str(c.pk)}
            for c in q.choices.all()
        ]
        review.append({
            "question": q,
            "choices": choices,
            "correct": any(c["is_correct"] and c["picked"] for c in choices),
            "skipped": picked is None,
        })
    return render(request, "assessments/result.html", {"attempt": attempt, "quiz": attempt.quiz, "review": review})


# ---------------------------------------------------------------- trainers

@trainer_required
def quiz_create(request, slug):
    course = get_object_or_404(Course, slug=slug)
    if not can_manage_course(request.user, course):
        raise PermissionDenied
    form = QuizForm(request.POST or None, initial={"title": f"{course.title} — Assessment"})
    if request.method == "POST" and form.is_valid():
        quiz = form.save(commit=False)
        quiz.course = course
        quiz.save()
        messages.success(request, "Assessment created. Add some questions.")
        return redirect("assessments:builder", pk=quiz.pk)
    return render(request, "assessments/quiz_form.html", {"form": form, "course": course})


@trainer_required
def quiz_builder(request, pk):
    quiz = _managed_quiz(request, pk)
    settings_form = QuizForm(instance=quiz)
    question_form = QuestionForm()
    if request.method == "POST":
        if "save_settings" in request.POST:
            settings_form = QuizForm(request.POST, instance=quiz)
            if settings_form.is_valid():
                settings_form.save()
                messages.success(request, "Assessment settings saved.")
                return redirect("assessments:builder", pk=quiz.pk)
        else:
            question_form = QuestionForm(request.POST)
            if question_form.is_valid():
                data = question_form.cleaned_data
                question = Question.objects.create(
                    quiz=quiz, text=data["text"], explanation=data["explanation"],
                    points=data["points"], order=quiz.questions.count() + 1,
                )
                for i in range(1, 5):
                    if data[f"choice_{i}"]:
                        Choice.objects.create(question=question, text=data[f"choice_{i}"], is_correct=data["correct"] == str(i))
                messages.success(request, "Question added.")
                return redirect("assessments:builder", pk=quiz.pk)
    questions = list(quiz.questions.prefetch_related("choices"))
    attempts = list(quiz.attempts.select_related("user")[:20])
    return render(request, "assessments/builder.html", {
        "quiz": quiz, "questions": questions, "settings_form": settings_form,
        "question_form": question_form, "attempts": attempts,
        "pass_rate": round(sum(a.passed for a in attempts) * 100 / len(attempts)) if attempts else None,
    })


@trainer_required
@require_POST
def question_delete(request, pk):
    question = get_object_or_404(Question.objects.select_related("quiz__course"), pk=pk)
    quiz = _managed_quiz(request, question.quiz_id)
    question.delete()
    messages.success(request, "Question removed.")
    return redirect("assessments:builder", pk=quiz.pk)


@trainer_required
@require_POST
def quiz_delete(request, pk):
    quiz = _managed_quiz(request, pk)
    slug = quiz.course.slug
    quiz.delete()
    messages.success(request, "Assessment deleted.")
    return redirect("courses:manage", slug=slug)
