from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def trainer_required(view):
    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_trainer:
            raise PermissionDenied("Trainer access required.")
        return view(request, *args, **kwargs)

    return wrapper


def admin_required(view):
    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_portal_admin:
            raise PermissionDenied("Administrator access required.")
        return view(request, *args, **kwargs)

    return wrapper


def can_manage_course(user, course):
    return user.is_authenticated and (user.is_portal_admin or course.instructor_id == user.pk)
