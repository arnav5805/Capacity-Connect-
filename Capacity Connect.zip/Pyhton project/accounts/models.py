from django.contrib.auth.models import AbstractUser
from django.db import models

AVATAR_COLORS = ["#4f46e5", "#0891b2", "#059669", "#d97706", "#db2777", "#7c3aed", "#2563eb", "#dc2626"]

DEPARTMENTS = [
    "Administration",
    "Finance",
    "Human Resources",
    "Information Technology",
    "Operations",
    "Research & Development",
    "Sales & Marketing",
    "Training & Development",
]


class User(AbstractUser):
    class Role(models.TextChoices):
        LEARNER = "learner", "Learner"
        TRAINER = "trainer", "Trainer"
        ADMIN = "admin", "Administrator"

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.LEARNER)
    department = models.CharField(max_length=100, blank=True)
    designation = models.CharField(max_length=100, blank=True)
    employee_id = models.CharField(max_length=30, blank=True)
    bio = models.TextField(blank=True)

    class Meta:
        ordering = ["first_name", "last_name", "username"]

    def __str__(self):
        return self.display_name

    @property
    def display_name(self):
        return self.get_full_name() or self.username

    @property
    def initials(self):
        if self.first_name or self.last_name:
            return f"{self.first_name[:1]}{self.last_name[:1]}".upper()
        return self.username[:2].upper()

    @property
    def avatar_color(self):
        return AVATAR_COLORS[sum(map(ord, self.username)) % len(AVATAR_COLORS)]

    @property
    def is_portal_admin(self):
        return self.is_superuser or self.role == self.Role.ADMIN

    @property
    def is_trainer(self):
        return self.is_portal_admin or self.role == self.Role.TRAINER
