from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

app_name = "accounts"

urlpatterns = [
    path("login/", views.LoginView.as_view(), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("register/", views.register, name="register"),
    path("profile/", views.profile, name="profile"),
    path("profile/edit/", views.profile_edit, name="profile_edit"),
    path("profile/password/", views.PasswordChangeView.as_view(), name="password_change"),
    path("people/<str:username>/", views.profile, name="person"),
    path("users/", views.user_list, name="users"),
    path("users/<oid:pk>/role/", views.user_set_role, name="set_role"),
]
