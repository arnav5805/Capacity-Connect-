from django import forms
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm, UserCreationForm

from core.forms import StyledFormMixin

from .models import DEPARTMENTS, User

DEPARTMENT_CHOICES = [("", "Select department")] + [(d, d) for d in DEPARTMENTS]


class LoginForm(StyledFormMixin, AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.update(placeholder="Your username", autofocus=True)
        self.fields["password"].widget.attrs.update(placeholder="••••••••")


class RegisterForm(StyledFormMixin, UserCreationForm):
    department = forms.ChoiceField(choices=DEPARTMENT_CHOICES)

    class Meta:
        model = User
        fields = ["first_name", "last_name", "username", "email", "employee_id", "department", "designation"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name in ["first_name", "last_name", "email"]:
            self.fields[name].required = True


class ProfileForm(StyledFormMixin, forms.ModelForm):
    department = forms.ChoiceField(choices=DEPARTMENT_CHOICES)

    class Meta:
        model = User
        fields = ["first_name", "last_name", "email", "employee_id", "department", "designation", "bio"]
        widgets = {"bio": forms.Textarea(attrs={"rows": 4, "placeholder": "Tell colleagues about your role and interests"})}


class StyledPasswordChangeForm(StyledFormMixin, PasswordChangeForm):
    pass
