from django.contrib import messages
from django.contrib.auth import login, views as auth_views
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.decorators.http import require_POST

from assessments.models import Attempt
from core.services import badges_for, level_for, points_for
from courses.models import Certificate, Enrollment
from courses.services import attach_course_stats
from knowledge.models import Post

from .decorators import admin_required
from .forms import LoginForm, ProfileForm, RegisterForm, StyledPasswordChangeForm
from .models import DEPARTMENTS, User


class LoginView(auth_views.LoginView):
    template_name = "accounts/login.html"
    authentication_form = LoginForm
    redirect_authenticated_user = True


class PasswordChangeView(auth_views.PasswordChangeView):
    template_name = "accounts/password_change.html"
    form_class = StyledPasswordChangeForm
    success_url = reverse_lazy("accounts:profile")

    def form_valid(self, form):
        messages.success(self.request, "Your password has been updated.")
        return super().form_valid(form)


def register(request):
    if request.user.is_authenticated:
        return redirect("core:dashboard")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, f"Welcome to Capacity Connect, {user.first_name}! Start by exploring the course catalog.")
        return redirect("core:dashboard")
    return render(request, "accounts/register.html", {"form": form})


@login_required
def profile(request, username=None):
    person = get_object_or_404(User, username=username) if username else request.user
    enrollments = list(Enrollment.objects.filter(user=person).select_related("course", "course__category"))
    courses = attach_course_stats([e.course for e in enrollments], person)
    points = points_for([person.pk])[person.pk]
    attempts = list(Attempt.objects.filter(user=person))
    context = {
        "person": person,
        "is_me": person == request.user,
        "courses": courses,
        "completed": [c for c in courses if c.my_enrollment and c.my_enrollment.is_completed],
        "certificates": Certificate.objects.filter(user=person).select_related("course"),
        "points": points,
        "level": level_for(points),
        "badges": badges_for(person),
        "avg_score": round(sum(a.score for a in attempts) / len(attempts)) if attempts else None,
        "posts": Post.objects.filter(author=person)[:5],
    }
    return render(request, "accounts/profile.html", context)


@login_required
def profile_edit(request):
    form = ProfileForm(request.POST or None, instance=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Profile updated.")
        return redirect("accounts:profile")
    return render(request, "accounts/profile_edit.html", {"form": form})


@admin_required
def user_list(request):
    users = User.objects.all()
    q = request.GET.get("q", "").strip()
    role = request.GET.get("role", "")
    dept = request.GET.get("department", "")
    if q:
        users = users.filter(
            Q(username__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(email__icontains=q)
        )
    if role:
        users = users.filter(role=role)
    if dept:
        users = users.filter(department=dept)
    page = Paginator(users, 15).get_page(request.GET.get("page"))
    ids = [u.pk for u in page]
    points = points_for(ids)
    enrolled, completed = {}, {}
    for uid, done in Enrollment.objects.filter(user_id__in=ids).values_list("user_id", "completed_at"):
        enrolled[uid] = enrolled.get(uid, 0) + 1
        if done:
            completed[uid] = completed.get(uid, 0) + 1
    for u in page:
        u.points = points[u.pk]
        u.num_enrolled = enrolled.get(u.pk, 0)
        u.num_completed = completed.get(u.pk, 0)
    return render(request, "accounts/user_list.html", {
        "page": page, "q": q, "role": role, "department": dept,
        "roles": User.Role.choices, "departments": DEPARTMENTS,
    })


@admin_required
@require_POST
def user_set_role(request, pk):
    person = get_object_or_404(User, pk=pk)
    role = request.POST.get("role")
    if role in User.Role.values and person != request.user:
        person.role = role
        person.save(update_fields=["role"])
        messages.success(request, f"{person.display_name} is now a {person.get_role_display()}.")
    else:
        messages.error(request, "You cannot change that role.")
    return redirect(request.META.get("HTTP_REFERER") or "accounts:users")
