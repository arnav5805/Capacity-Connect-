from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class PortalUserAdmin(UserAdmin):
    list_display = ("username", "get_full_name", "email", "role", "department", "is_active")
    list_filter = ("role", "department", "is_active", "is_staff")
    search_fields = ("username", "first_name", "last_name", "email", "employee_id")
    fieldsets = UserAdmin.fieldsets + (
        ("Portal profile", {"fields": ("role", "department", "designation", "employee_id", "bio")}),
    )
