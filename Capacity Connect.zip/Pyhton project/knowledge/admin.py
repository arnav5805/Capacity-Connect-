from django.contrib import admin

from .models import Comment, Post


class CommentInline(admin.TabularInline):
    model = Comment
    extra = 0


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "kind", "views", "created_at")
    list_filter = ("kind",)
    search_fields = ("title", "body", "tags")
    inlines = [CommentInline]
