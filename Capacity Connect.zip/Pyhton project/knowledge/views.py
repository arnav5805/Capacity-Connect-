from collections import Counter

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db.models import F, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.models import User

from .forms import CommentForm, PostForm
from .models import Comment, Post


def _can_edit(user, post):
    return post.author_id == user.pk or user.is_portal_admin


@login_required
def post_list(request):
    posts = Post.objects.select_related("author")
    q = request.GET.get("q", "").strip()
    kind = request.GET.get("kind", "")
    tag = request.GET.get("tag", "").strip().lower()
    sort = request.GET.get("sort", "latest")
    if q:
        posts = posts.filter(Q(title__icontains=q) | Q(body__icontains=q) | Q(tags__icontains=q))
    if kind:
        posts = posts.filter(kind=kind)
    if tag:
        posts = posts.filter(tags__icontains=tag)
    if sort == "popular":
        posts = posts.order_by("-views")
    page = Paginator(posts, 10).get_page(request.GET.get("page"))
    ids = [p.pk for p in page]
    comment_counts = Counter(Comment.objects.filter(post_id__in=ids).values_list("post_id", flat=True))
    liked = set(request.user.liked_posts.filter(id__in=ids).values_list("id", flat=True))
    for p in page:
        p.num_comments = comment_counts[p.pk]
        p.num_likes = p.likes.count()
        p.is_liked = p.pk in liked
    all_tags = Counter(t for tags in Post.objects.values_list("tags", flat=True) for t in
                       [x.strip().lower() for x in tags.split(",")] if t)
    contributors = Counter(Post.objects.values_list("author_id", flat=True)).most_common(5)
    people = {u.pk: u for u in User.objects.filter(id__in=[uid for uid, _ in contributors])}
    return render(request, "knowledge/list.html", {
        "page": page, "q": q, "kind": kind, "tag": tag, "sort": sort,
        "kinds": Post.Kind.choices,
        "tags": all_tags.most_common(12),
        "contributors": [(people[uid], n) for uid, n in contributors if uid in people],
    })


@login_required
def post_detail(request, pk):
    post = get_object_or_404(Post.objects.select_related("author"), pk=pk)
    Post.objects.filter(pk=post.pk).update(views=F("views") + 1)
    form = CommentForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        comment = form.save(commit=False)
        comment.post, comment.author = post, request.user
        comment.save()
        messages.success(request, "Comment posted.")
        return redirect(post.get_absolute_url() + "#comments")
    related = Post.objects.exclude(pk=post.pk).filter(kind=post.kind)[:4]
    return render(request, "knowledge/detail.html", {
        "post": post,
        "comments": post.comments.select_related("author"),
        "form": form,
        "num_likes": post.likes.count(),
        "is_liked": post.likes.filter(pk=request.user.pk).exists(),
        "can_edit": _can_edit(request.user, post),
        "related": related,
    })


@login_required
def post_form(request, pk=None):
    post = get_object_or_404(Post, pk=pk) if pk else None
    if post and not _can_edit(request.user, post):
        raise PermissionDenied
    form = PostForm(request.POST or None, instance=post)
    if request.method == "POST" and form.is_valid():
        obj = form.save(commit=False)
        if not post:
            obj.author = request.user
        obj.save()
        messages.success(request, "Post published to the Knowledge Hub." if not post else "Post updated.")
        return redirect(obj)
    return render(request, "knowledge/form.html", {"form": form, "post": post})


@login_required
@require_POST
def post_delete(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if not _can_edit(request.user, post):
        raise PermissionDenied
    post.delete()
    messages.success(request, "Post deleted.")
    return redirect("knowledge:list")


@login_required
@require_POST
def post_like(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if post.likes.filter(pk=request.user.pk).exists():
        post.likes.remove(request.user)
        liked = False
    else:
        post.likes.add(request.user)
        liked = True
    if request.headers.get("x-requested-with") == "fetch":
        return JsonResponse({"liked": liked, "count": post.likes.count()})
    return redirect(post)
