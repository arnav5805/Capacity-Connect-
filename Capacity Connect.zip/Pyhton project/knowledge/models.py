from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone


class Post(models.Model):
    class Kind(models.TextChoices):
        ARTICLE = "article", "Article"
        TIP = "tip", "Quick Tip"
        QUESTION = "question", "Question"
        RESOURCE = "resource", "Resource"

    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="posts")
    title = models.CharField(max_length=200)
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.ARTICLE)
    body = models.TextField(help_text="Supports simple markdown (## headings, - lists, **bold**, `code`).")
    link = models.URLField(blank=True, help_text="Optional external resource link")
    tags = models.CharField(max_length=200, blank=True, help_text="Comma separated, e.g. excel, reporting")
    views = models.PositiveIntegerField(default=0)
    likes = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True, related_name="liked_posts")
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("knowledge:detail", args=[self.pk])

    @property
    def tag_list(self):
        return [t.strip().lower() for t in self.tags.split(",") if t.strip()]


class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="comments")
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="comments")
    body = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["created_at"]
