from django import forms

from core.forms import StyledFormMixin

from .models import Comment, Post


class PostForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Post
        fields = ["title", "kind", "tags", "link", "body"]
        widgets = {"body": forms.Textarea(attrs={"rows": 12})}


class CommentForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["body"]
        labels = {"body": ""}
        widgets = {"body": forms.Textarea(attrs={"rows": 3, "placeholder": "Share your thoughts or answer…"})}
