from django.urls import path

from . import views

app_name = "knowledge"

urlpatterns = [
    path("", views.post_list, name="list"),
    path("new/", views.post_form, name="create"),
    path("<oid:pk>/", views.post_detail, name="detail"),
    path("<oid:pk>/edit/", views.post_form, name="edit"),
    path("<oid:pk>/delete/", views.post_delete, name="delete"),
    path("<oid:pk>/like/", views.post_like, name="like"),
]
