from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path, register_converter

from .converters import ObjectIdConverter

register_converter(ObjectIdConverter, "oid")

admin.site.site_header = "Capacity Connect Administration"
admin.site.site_title = "Capacity Connect"
admin.site.index_title = "Portal data management"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/", include("accounts.urls")),
    path("courses/", include("courses.urls")),
    path("assessments/", include("assessments.urls")),
    path("knowledge/", include("knowledge.urls")),
    path("", include("core.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
