/* Capacity Connect — small progressive-enhancement scripts */
(function () {
  "use strict";
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function icons() { if (window.lucide) window.lucide.createIcons(); }
  icons();

  // ---- Theme toggle ----
  $$("[data-theme-toggle]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = next;
      try { localStorage.setItem("cc-theme", next); } catch (e) { /* storage unavailable */ }
      document.dispatchEvent(new CustomEvent("themechange"));
    })
  );

  // ---- Mobile sidebar ----
  const sidebar = $("#sidebar");
  const backdrop = $("#backdrop");
  const toggleSidebar = (open) => {
    if (!sidebar) return;
    sidebar.classList.toggle("open", open);
    backdrop && backdrop.classList.toggle("show", open);
  };
  $$("[data-menu]").forEach((b) => b.addEventListener("click", () => toggleSidebar(!sidebar.classList.contains("open"))));
  backdrop && backdrop.addEventListener("click", () => toggleSidebar(false));

  // ---- Toasts ----
  $$(".toast").forEach((t, i) => {
    const ms = 5000 + i * 800;
    t.style.setProperty("--toast-ms", ms + "ms");
    const close = () => { t.classList.add("hide"); setTimeout(() => t.remove(), 300); };
    $(".close", t) && $(".close", t).addEventListener("click", close);
    setTimeout(close, ms);
  });

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---- Scroll reveal with stagger ----
  if ("IntersectionObserver" in window && !reduceMotion) {
    const targets = $$(".content .grid > *, .content .layout-main > * > .card, .content .layout-main > .card, .content > .card, .section .card, .podium-item, .post-card, .announce");
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("revealed");
        entry.target.classList.remove("will-reveal");
        io.unobserve(entry.target);
      });
    }, { threshold: 0.08, rootMargin: "0px 0px -30px 0px" });
    targets.forEach((el) => {
      const siblings = el.parentElement ? Array.from(el.parentElement.children) : [];
      el.style.setProperty("--d", Math.min(siblings.indexOf(el), 8) * 60 + "ms");
      el.classList.add("will-reveal");
      io.observe(el);
    });
    // Drop the reveal classes afterwards so each component's own hover transitions apply again
    document.addEventListener("transitionend", (e) => {
      if (e.propertyName === "opacity" && e.target.classList && e.target.classList.contains("revealed")) {
        e.target.classList.remove("revealed");
        e.target.style.removeProperty("--d");
      }
    });
  }

  // ---- Count-up numbers ----
  if (!reduceMotion) {
    $$(".stat-value, .hero-stats .v, .pts").forEach((el) => {
      const m = el.textContent.trim().match(/^(\d+)(.*)$/);
      if (!m || el.children.length) return;
      const target = parseInt(m[1], 10), suffix = m[2];
      if (target < 2) return;
      const start = performance.now(), dur = 900;
      const step = (now) => {
        const t = Math.min((now - start) / dur, 1);
        el.textContent = Math.round(target * (1 - Math.pow(1 - t, 3))) + suffix;
        if (t < 1) requestAnimationFrame(step);
      };
      el.textContent = "0" + suffix;
      requestAnimationFrame(step);
    });
  }

  // ---- Animate progress bars from zero ----
  if (!reduceMotion) {
    const bars = $$(".progress > span");
    bars.forEach((b) => { b.dataset.w = b.style.width; b.style.width = "0"; });
    requestAnimationFrame(() => setTimeout(() => bars.forEach((b) => { b.style.width = b.dataset.w; }), 80));
  }

  // ---- Top bar shadow + back to top ----
  const topbar = $(".topbar");
  const toTop = document.createElement("button");
  toTop.className = "to-top";
  toTop.setAttribute("aria-label", "Back to top");
  toTop.innerHTML = '<i data-lucide="arrow-up"></i>';
  document.body.appendChild(toTop);
  toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" }));
  const onScroll = () => {
    const y = window.scrollY;
    topbar && topbar.classList.toggle("scrolled", y > 8);
    toTop.classList.toggle("show", y > 500);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  // ---- Navigation progress bar ----
  const navBar = document.createElement("div");
  navBar.className = "nav-progress";
  document.body.appendChild(navBar);
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[href]");
    if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    const href = a.getAttribute("href");
    if (!href || href.startsWith("#") || a.target === "_blank" || a.hasAttribute("download") || a.origin !== location.origin) return;
    document.body.classList.add("is-navigating");
  });
  window.addEventListener("pageshow", () => document.body.classList.remove("is-navigating"));

  // ---- Loading state on form submit ----
  document.addEventListener("submit", (e) => {
    if (e.defaultPrevented) return;
    const form = e.target;
    const btn = e.submitter || $("button:not([type=button])", form);
    if (!btn || btn.classList.contains("icon-btn-dark") || form.method.toLowerCase() === "get") return;
    setTimeout(() => btn.classList.add("is-loading"), 0);
    document.body.classList.add("is-navigating");
  });

  // ---- Keyboard: "/" focuses search ----
  const search = $(".search-box input");
  if (search) {
    const kbd = document.createElement("span");
    kbd.className = "kbd";
    kbd.textContent = "/";
    search.after(kbd);
    document.addEventListener("keydown", (e) => {
      if (e.key === "/" && !/input|textarea|select/i.test(document.activeElement.tagName)) {
        e.preventDefault();
        search.focus();
      }
    });
  }
  icons();

  // ---- Confirm dangerous actions ----
  $$("form[data-confirm]").forEach((f) =>
    f.addEventListener("submit", (e) => { if (!confirm(f.dataset.confirm)) e.preventDefault(); })
  );

  // ---- Tabs ----
  $$("[data-tabs]").forEach((group) => {
    const tabs = $$(".tab", group);
    tabs.forEach((tab) =>
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.toggle("active", t === tab));
        $$(`[data-tab-panel="${group.dataset.tabs}"]`).forEach((p) =>
          p.classList.toggle("active", p.id === tab.dataset.target)
        );
      })
    );
  });

  // ---- Auto-submit filters ----
  $$("[data-autosubmit]").forEach((el) => el.addEventListener("change", () => el.form.submit()));

  // ---- Demo login buttons ----
  $$("[data-demo-user]").forEach((b) =>
    b.addEventListener("click", () => {
      $("#id_username").value = b.dataset.demoUser;
      $("#id_password").value = b.dataset.demoPass;
      $("#id_username").form.submit();
    })
  );

  // ---- Like button (AJAX) ----
  $$("[data-like]").forEach((form) =>
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = $("button", form);
      try {
        const res = await fetch(form.action, {
          method: "POST",
          headers: { "X-CSRFToken": form.csrfmiddlewaretoken.value, "X-Requested-With": "fetch" },
        });
        const data = await res.json();
        btn.classList.toggle("liked", data.liked);
        $("[data-like-count]", form).textContent = data.count;
      } catch (err) { form.submit(); }
    })
  );

  // ---- Quiz: answered tracker + countdown timer ----
  const quiz = $("#quiz-form");
  if (quiz) {
    const update = () => {
      let answered = 0;
      $$(".question", quiz).forEach((q, i) => {
        const done = !!$("input:checked", q);
        answered += done;
        const dot = $(`[data-dot="${i}"]`);
        dot && dot.classList.toggle("answered", done);
      });
      const counter = $("#answered-count");
      if (counter) counter.textContent = answered;
    };
    quiz.addEventListener("change", update);
    update();

    let submitted = false;
    quiz.addEventListener("submit", (e) => {
      const total = $$(".question", quiz).length;
      const answered = $$(".question", quiz).filter((q) => $("input:checked", q)).length;
      if (!submitted && answered < total && !confirm(`You answered ${answered} of ${total} questions. Submit anyway?`)) {
        e.preventDefault();
        return;
      }
      submitted = true;
      window.onbeforeunload = null;
    });
    window.onbeforeunload = () => (submitted ? undefined : "Your answers will be lost.");

    const timer = $("#timer");
    let remaining = parseInt(quiz.dataset.timeLimit || "0", 10);
    if (timer && remaining > 0) {
      const tick = () => {
        const m = Math.floor(remaining / 60), s = remaining % 60;
        $("span", timer).textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
        timer.classList.toggle("low", remaining <= 60);
        if (remaining <= 0) {
          submitted = true;
          window.onbeforeunload = null;
          quiz.submit();
          return;
        }
        remaining -= 1;
        setTimeout(tick, 1000);
      };
      tick();
    }
  }

  // ---- Charts (Chart.js) ----
  window.ccChart = function (id, config) {
    const el = document.getElementById(id);
    if (!el || !window.Chart) return;
    const css = getComputedStyle(document.documentElement);
    const color = (v) => css.getPropertyValue(v).trim();
    Chart.defaults.font.family = color("--font") || "sans-serif";
    Chart.defaults.color = color("--muted");
    Chart.defaults.borderColor = color("--border");
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.plugins.legend.labels.boxWidth = 8;
    const chart = new Chart(el, Object.assign({ options: {} }, config));
    document.addEventListener("themechange", () => {
      chart.destroy();
      window.ccChart(id, config);
    }, { once: true });
    return chart;
  };
})();
