import csv
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from accounts.decorators import trainer_required
from accounts.models import User
from assessments.models import Attempt, Quiz
from courses.models import Category, Certificate, Course, Enrollment, LessonProgress
from courses.services import attach_course_stats, progress_map
from knowledge.models import Post

from .forms import AnnouncementForm
from .models import Announcement
from .services import badges_for, level_for, points_for


def home(request):
    if request.user.is_authenticated:
        return redirect("core:dashboard")
    stats = {
        "courses": Course.objects.filter(status=Course.Status.PUBLISHED).count(),
        "learners": User.objects.count(),
        "certificates": Certificate.objects.count(),
        "posts": Post.objects.count(),
    }
    featured = attach_course_stats(Course.objects.filter(status=Course.Status.PUBLISHED).select_related("category")[:3])
    return render(request, "core/home.html", {"stats": stats, "featured": featured})


def _activity_series(user, days=14):
    today = timezone.localdate()
    start = today - timedelta(days=days - 1)
    counts = Counter(
        timezone.localtime(ts).date()
        for ts in LessonProgress.objects.filter(
            user=user, completed_at__gte=timezone.make_aware(datetime.combine(start, time.min))
        ).values_list("completed_at", flat=True)
    )
    labels = [(start + timedelta(days=i)) for i in range(days)]
    return [d.strftime("%d %b") for d in labels], [counts[d] for d in labels]


@login_required
def dashboard(request):
    user = request.user
    enrollments = list(Enrollment.objects.filter(user=user).select_related("course", "course__category", "last_lesson"))
    courses = attach_course_stats([e.course for e in enrollments], user)
    in_progress = [c for c in courses if not c.my_enrollment.is_completed]
    completed = [c for c in courses if c.my_enrollment.is_completed]
    enrolled_ids = [c.pk for c in courses]

    recommended = Course.objects.filter(status=Course.Status.PUBLISHED).exclude(id__in=enrolled_ids).select_related("category")
    recommended = sorted(attach_course_stats(recommended), key=lambda c: (not c.is_mandatory, -c.num_enrolled))[:3]
    mandatory_pending = [c for c in in_progress if c.is_mandatory] + [c for c in recommended if c.is_mandatory]

    attempts = list(Attempt.objects.filter(user=user).select_related("quiz", "quiz__course")[:5])
    all_scores = list(Attempt.objects.filter(user=user).values_list("score", flat=True))
    points = points_for([user.pk])[user.pk]
    labels, values = _activity_series(user)

    context = {
        "in_progress": in_progress[:4],
        "recommended": recommended,
        "mandatory_pending": mandatory_pending,
        "stats": {
            "enrolled": len(courses),
            "in_progress": len(in_progress),
            "completed": len(completed),
            "certificates": Certificate.objects.filter(user=user).count(),
            "avg_score": round(sum(all_scores) / len(all_scores)) if all_scores else 0,
            "lessons": LessonProgress.objects.filter(user=user).count(),
        },
        "points": points,
        "level": level_for(points),
        "badges": badges_for(user),
        "attempts": attempts,
        "announcements": Announcement.objects.select_related("author")[:3],
        "activity_labels": labels,
        "activity_values": values,
        "hour": timezone.localtime().hour,
    }

    if user.is_trainer:
        my_courses = Course.objects.all() if user.is_portal_admin else Course.objects.filter(instructor=user)
        my_courses = attach_course_stats(my_courses.select_related("category"))
        ids = [c.pk for c in my_courses]
        course_enrollments = list(Enrollment.objects.filter(course_id__in=ids).values_list("user_id", "completed_at"))
        quiz_ids = list(Quiz.objects.filter(course_id__in=ids).values_list("id", flat=True))
        context["trainer"] = {
            "courses": len(my_courses),
            "published": sum(c.is_published for c in my_courses),
            "learners": len({uid for uid, _ in course_enrollments}),
            "enrollments": len(course_enrollments),
            "completion_rate": round(sum(1 for _, d in course_enrollments if d) * 100 / len(course_enrollments)) if course_enrollments else 0,
            "recent_attempts": Attempt.objects.filter(quiz_id__in=quiz_ids).select_related("user", "quiz")[:6],
            "top_courses": sorted(my_courses, key=lambda c: c.num_enrolled, reverse=True)[:4],
        }
    return render(request, "core/dashboard.html", context)


def _analytics_scope(user):
    courses = Course.objects.select_related("category", "instructor")
    if not user.is_portal_admin:
        courses = courses.filter(instructor=user)
    return list(courses)


@trainer_required
def analytics(request):
    courses = _analytics_scope(request.user)
    course_ids = [c.pk for c in courses]
    by_id = {c.pk: c for c in courses}
    enrollments = list(Enrollment.objects.filter(course_id__in=course_ids).select_related("user"))
    quizzes = list(Quiz.objects.filter(course_id__in=course_ids))
    attempts = list(Attempt.objects.filter(quiz_id__in=[q.pk for q in quizzes]).select_related("user"))

    # Course performance
    per_course = defaultdict(lambda: {"enrolled": 0, "completed": 0})
    for e in enrollments:
        per_course[e.course_id]["enrolled"] += 1
        per_course[e.course_id]["completed"] += e.is_completed
    top = sorted(courses, key=lambda c: per_course[c.pk]["enrolled"], reverse=True)[:8]

    # Department participation
    dept_learners, dept_completed = defaultdict(set), defaultdict(int)
    for e in enrollments:
        dept = e.user.department or "Unassigned"
        dept_learners[dept].add(e.user_id)
        dept_completed[dept] += e.is_completed
    departments = sorted(dept_learners, key=lambda d: len(dept_learners[d]), reverse=True)

    # Monthly enrolment trend (last 6 months)
    now = timezone.localtime()
    months = []
    for i in range(5, -1, -1):
        y, m = now.year, now.month - i
        while m <= 0:
            m += 12
            y -= 1
        months.append((y, m))
    month_enrol = Counter((timezone.localtime(e.enrolled_at).year, timezone.localtime(e.enrolled_at).month) for e in enrollments)
    month_done = Counter(
        (timezone.localtime(e.completed_at).year, timezone.localtime(e.completed_at).month) for e in enrollments if e.completed_at
    )

    # Assessment performance
    quiz_stats = []
    for q in quizzes:
        qa = [a for a in attempts if a.quiz_id == q.pk]
        if qa:
            quiz_stats.append({
                "quiz": q, "course": by_id[q.course_id], "attempts": len(qa),
                "avg": round(sum(a.score for a in qa) / len(qa)),
                "pass_rate": round(sum(a.passed for a in qa) * 100 / len(qa)),
            })

    # Category split
    cat_counts = Counter(by_id[e.course_id].category.name if by_id[e.course_id].category else "Other" for e in enrollments)
    cat_colors = {c.name: c.color for c in Category.objects.all()}

    # Top learners within scope
    learner_points = points_for(list({e.user_id for e in enrollments}))
    users = {e.user_id: e.user for e in enrollments}
    leaders = sorted(learner_points.items(), key=lambda kv: kv[1], reverse=True)[:5]

    completed_total = sum(e.is_completed for e in enrollments)
    context = {
        "summary": {
            "courses": len(courses),
            "learners": len(users),
            "enrollments": len(enrollments),
            "completion_rate": round(completed_total * 100 / len(enrollments)) if enrollments else 0,
            "avg_score": round(sum(a.score for a in attempts) / len(attempts)) if attempts else 0,
            "pass_rate": round(sum(a.passed for a in attempts) * 100 / len(attempts)) if attempts else 0,
            "certificates": Certificate.objects.filter(course_id__in=course_ids).count(),
            "total_users": User.objects.count(),
        },
        "course_chart": {
            "labels": [c.title[:28] + ("…" if len(c.title) > 28 else "") for c in top],
            "enrolled": [per_course[c.pk]["enrolled"] for c in top],
            "completed": [per_course[c.pk]["completed"] for c in top],
        },
        "dept_chart": {
            "labels": departments,
            "learners": [len(dept_learners[d]) for d in departments],
            "completed": [dept_completed[d] for d in departments],
        },
        "trend_chart": {
            "labels": [date(y, m, 1).strftime("%b %Y") for y, m in months],
            "enrolled": [month_enrol[k] for k in months],
            "completed": [month_done[k] for k in months],
        },
        "cat_chart": {
            "labels": list(cat_counts),
            "values": list(cat_counts.values()),
            "colors": [cat_colors.get(n, "#94a3b8") for n in cat_counts],
        },
        "quiz_stats": quiz_stats,
        "course_rows": [
            {"course": c, **per_course[c.pk],
             "rate": round(per_course[c.pk]["completed"] * 100 / per_course[c.pk]["enrolled"]) if per_course[c.pk]["enrolled"] else 0}
            for c in sorted(courses, key=lambda c: per_course[c.pk]["enrolled"], reverse=True)
        ],
        "leaders": [(users[uid], pts) for uid, pts in leaders],
    }
    return render(request, "core/analytics.html", context)


@trainer_required
def export_report(request):
    courses = _analytics_scope(request.user)
    enrollments = list(Enrollment.objects.filter(course_id__in=[c.pk for c in courses]).select_related("user", "course"))
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="capacity-connect-report-{timezone.localdate()}.csv"'
    writer = csv.writer(response)
    writer.writerow(["Employee ID", "Name", "Username", "Department", "Course", "Enrolled on", "Progress %", "Best score %", "Completed on"])
    best = {}
    for uid, qid, score in Attempt.objects.values_list("user_id", "quiz__course_id", "score"):
        best[(uid, qid)] = max(best.get((uid, qid), 0), score)
    progress_cache = {}
    for e in enrollments:
        if e.user_id not in progress_cache:
            progress_cache[e.user_id] = progress_map(e.user, [c.pk for c in courses])
        writer.writerow([
            e.user.employee_id, e.user.display_name, e.user.username, e.user.department, e.course.title,
            timezone.localtime(e.enrolled_at).strftime("%Y-%m-%d"),
            progress_cache[e.user_id].get(e.course_id, 0),
            best.get((e.user_id, e.course_id), ""),
            timezone.localtime(e.completed_at).strftime("%Y-%m-%d") if e.completed_at else "",
        ])
    return response


@login_required
def leaderboard(request):
    dept = request.GET.get("department", "")
    users = User.objects.filter(is_active=True)
    if dept:
        users = users.filter(department=dept)
    users = list(users)
    points = points_for([u.pk for u in users])
    certs = Counter(Certificate.objects.values_list("user_id", flat=True))
    for u in users:
        u.points = points[u.pk]
        u.level = level_for(u.points)
        u.num_certificates = certs[u.pk]
    ranked = sorted(users, key=lambda u: u.points, reverse=True)
    my_rank = next((i + 1 for i, u in enumerate(ranked) if u.pk == request.user.pk), None)
    departments = sorted({d for d in User.objects.values_list("department", flat=True) if d})
    return render(request, "core/leaderboard.html", {
        "podium": ranked[:3], "rest": ranked[3:25], "my_rank": my_rank,
        "department": dept, "departments": departments,
    })


@login_required
def announcements(request):
    form = AnnouncementForm(request.POST or None)
    if request.method == "POST":
        if not request.user.is_trainer:
            return redirect("core:announcements")
        if form.is_valid():
            obj = form.save(commit=False)
            obj.author = request.user
            obj.save()
            messages.success(request, "Announcement published to all users.")
            return redirect("core:announcements")
    return render(request, "core/announcements.html", {
        "announcements": Announcement.objects.select_related("author"),
        "form": form,
    })


@trainer_required
@require_POST
def announcement_delete(request, pk):
    obj = get_object_or_404(Announcement, pk=pk)
    if obj.author_id == request.user.pk or request.user.is_portal_admin:
        obj.delete()
        messages.success(request, "Announcement removed.")
    return redirect("core:announcements")


@login_required
def search(request):
    q = request.GET.get("q", "").strip()
    courses, posts, people = [], [], []
    if q:
        courses = attach_course_stats(
            Course.objects.filter(status=Course.Status.PUBLISHED)
            .filter(Q(title__icontains=q) | Q(summary__icontains=q) | Q(description__icontains=q))
            .select_related("category")[:12],
            request.user,
        )
        posts = Post.objects.filter(Q(title__icontains=q) | Q(body__icontains=q) | Q(tags__icontains=q)).select_related("author")[:10]
        people = User.objects.filter(
            Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(username__icontains=q) | Q(department__icontains=q)
        )[:8]
    return render(request, "core/search.html", {"q": q, "courses": courses, "posts": posts, "people": people})
