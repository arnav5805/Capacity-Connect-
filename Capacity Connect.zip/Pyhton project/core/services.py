"""Gamification: points, levels and badges computed from learning activity."""
from collections import defaultdict

from assessments.models import Attempt
from courses.models import Certificate, Enrollment, LessonProgress
from knowledge.models import Comment, Post

POINTS = {"lesson": 10, "course": 100, "post": 15, "comment": 5}

LEVELS = [
    (0, "Starter", "sprout"),
    (150, "Explorer", "compass"),
    (400, "Achiever", "target"),
    (800, "Expert", "gem"),
    (1500, "Master", "crown"),
]

BADGES = [
    ("first_steps", "First Steps", "footprints", "Completed your first lesson"),
    ("finisher", "Course Finisher", "flag", "Completed a full course"),
    ("quiz_ace", "Quiz Ace", "zap", "Scored 100% on an assessment"),
    ("sharer", "Knowledge Sharer", "share-2", "Published a Knowledge Hub post"),
    ("collector", "Certified Pro", "award", "Earned 3 or more certificates"),
    ("committed", "Committed Learner", "flame", "Enrolled in 4 or more courses"),
]


def points_for(user_ids=None):
    """{user_id: points}. Pass None to compute for everyone (leaderboard)."""
    def scoped(qs, field="user_id"):
        return qs.filter(**{f"{field}__in": list(user_ids)}) if user_ids is not None else qs

    points = defaultdict(int)
    for uid in scoped(LessonProgress.objects.all()).values_list("user_id", flat=True):
        points[uid] += POINTS["lesson"]
    for uid in scoped(Enrollment.objects.filter(completed_at__isnull=False)).values_list("user_id", flat=True):
        points[uid] += POINTS["course"]
    best = {}
    for uid, qid, score in scoped(Attempt.objects.all()).values_list("user_id", "quiz_id", "score"):
        best[(uid, qid)] = max(best.get((uid, qid), 0), score)
    for (uid, _), score in best.items():
        points[uid] += round(score / 2)  # up to 50 points per assessment
    for uid in scoped(Post.objects.all(), "author_id").values_list("author_id", flat=True):
        points[uid] += POINTS["post"]
    for uid in scoped(Comment.objects.all(), "author_id").values_list("author_id", flat=True):
        points[uid] += POINTS["comment"]
    return points


def level_for(points):
    current, nxt = LEVELS[0], None
    for i, lvl in enumerate(LEVELS):
        if points >= lvl[0]:
            current = lvl
            nxt = LEVELS[i + 1] if i + 1 < len(LEVELS) else None
    progress = 100
    if nxt:
        progress = round((points - current[0]) * 100 / (nxt[0] - current[0]))
    return {
        "name": current[1],
        "icon": current[2],
        "next_name": nxt[1] if nxt else None,
        "next_points": nxt[0] if nxt else None,
        "to_next": (nxt[0] - points) if nxt else 0,
        "progress": progress,
    }


def badges_for(user):
    earned = {
        "first_steps": LessonProgress.objects.filter(user=user).exists(),
        "finisher": Enrollment.objects.filter(user=user, completed_at__isnull=False).exists(),
        "quiz_ace": Attempt.objects.filter(user=user, score__gte=100).exists(),
        "sharer": Post.objects.filter(author=user).exists(),
        "collector": Certificate.objects.filter(user=user).count() >= 3,
        "committed": Enrollment.objects.filter(user=user).count() >= 4,
    }
    return [
        {"key": key, "name": name, "icon": icon, "description": desc, "earned": earned[key]}
        for key, name, icon, desc in BADGES
    ]
