from .models import Announcement


def portal(request):
    """Global template context: latest announcement for the topbar bell."""
    if not request.user.is_authenticated:
        return {}
    latest = Announcement.objects.only("title", "created_at").first()
    return {"latest_announcement": latest}
