from django.urls import path

from . import views

app_name = "core"

urlpatterns = [
    path("", views.home, name="home"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("analytics/", views.analytics, name="analytics"),
    path("analytics/export/", views.export_report, name="export"),
    path("leaderboard/", views.leaderboard, name="leaderboard"),
    path("announcements/", views.announcements, name="announcements"),
    path("announcements/<oid:pk>/delete/", views.announcement_delete, name="announcement_delete"),
    path("search/", views.search, name="search"),
]
