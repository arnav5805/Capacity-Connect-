import re

from django import template
from django.utils.html import escape
from django.utils.safestring import mark_safe

register = template.Library()


@register.simple_tag(takes_context=True)
def nav_active(context, *names):
    """Return 'active' when the current view matches any name (supports 'app:*')."""
    match = getattr(context.get("request"), "resolver_match", None)
    if not match:
        return ""
    current = match.view_name
    for name in names:
        if name == current or (name.endswith("*") and current.startswith(name[:-1])):
            return "active"
    return ""


def _inline(text):
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"(?<![*\w])\*([^*]+)\*(?!\*)", r"<em>\1</em>", text)
    text = re.sub(r"\[([^\]]+)\]\((https?://[^)\s]+)\)", r'<a href="\2" target="_blank" rel="noopener">\1</a>', text)
    return text


@register.filter
def markdown(value):
    """A small, safe markdown subset. Input is HTML-escaped before formatting."""
    if not value:
        return ""
    lines = escape(value).splitlines()
    html, list_tag, para, in_code = [], None, [], False

    def flush_para():
        if para:
            html.append(f"<p>{_inline(' '.join(para))}</p>")
            para.clear()

    def close_list():
        nonlocal list_tag
        if list_tag:
            html.append(f"</{list_tag}>")
            list_tag = None

    for raw in lines:
        line = raw.rstrip()
        if line.startswith("```"):
            flush_para()
            close_list()
            html.append("</code></pre>" if in_code else "<pre><code>")
            in_code = not in_code
            continue
        if in_code:
            html.append(line + "\n")
            continue
        stripped = line.strip()
        heading = re.match(r"^(#{1,3})\s+(.*)", stripped)
        bullet = re.match(r"^[-*]\s+(.*)", stripped)
        numbered = re.match(r"^\d+[.)]\s+(.*)", stripped)
        if not stripped:
            flush_para()
            close_list()
        elif heading:
            flush_para()
            close_list()
            level = len(heading.group(1)) + 1
            html.append(f"<h{level}>{_inline(heading.group(2))}</h{level}>")
        elif stripped.startswith("&gt;"):
            flush_para()
            close_list()
            html.append(f"<blockquote>{_inline(stripped[4:].strip())}</blockquote>")
        elif bullet or numbered:
            flush_para()
            tag = "ul" if bullet else "ol"
            if list_tag != tag:
                close_list()
                html.append(f"<{tag}>")
                list_tag = tag
            html.append(f"<li>{_inline((bullet or numbered).group(1))}</li>")
        else:
            close_list()
            para.append(stripped)
    flush_para()
    close_list()
    if in_code:
        html.append("</code></pre>")
    return mark_safe("".join(html))


@register.filter
def stars(value):
    """Render a 0-5 rating as filled/empty star characters."""
    try:
        value = round(float(value or 0))
    except (TypeError, ValueError):
        value = 0
    return "★" * value + "☆" * (5 - value)


@register.filter
def get_item(mapping, key):
    return mapping.get(key) if mapping else None


@register.filter
def pct_class(value):
    """Colour class for a percentage score."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return ""
    if value >= 80:
        return "good"
    if value >= 50:
        return "warn"
    return "bad"
